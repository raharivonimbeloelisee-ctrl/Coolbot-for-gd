// MiniGames : remplace (ou complète) le bouton "The Map" du menu Créer par "The Game".
#include <Geode/Geode.hpp>
#include <Geode/modify/CreatorLayer.hpp>

#include "Game.hpp"

using namespace geode::prelude;

static CCMenuItem* findMapButton(CCNode* n) {
    if (!n) return nullptr;
    if (auto it = typeinfo_cast<CCMenuItem*>(n)) {
        if (it->m_pfnSelector == menu_selector(CreatorLayer::onAdventureMap)) return it;
    }
    if (auto ch = n->getChildren()) {
        for (auto* c : CCArrayExt<CCNode*>(ch)) {
            if (auto r = findMapButton(c)) return r;
        }
    }
    return nullptr;
}

class $modify(MGCreatorLayer, CreatorLayer) {
    bool init() {
        if (!CreatorLayer::init()) return false;

        bool replace = Mod::get()->getSettingValue<bool>("replace_map");
        auto item = findMapButton(this);
        CCSize size = item ? item->getContentSize() : CCSize{70.f, 70.f};
        if (size.width < 20.f) size = {70.f, 70.f};

        if (replace && item) {
            item->setTarget(this, menu_selector(MGCreatorLayer::onTheGame));
            item->setEnabled(true);
            if (auto se = typeinfo_cast<CCMenuItemSpriteExtra*>(item)) {
                se->setSprite(mg::makeGameButtonSprite(size));
            }
        } else {
            auto btn = CCMenuItemSpriteExtra::create(
                mg::makeGameButtonSprite({60.f, 60.f}), this, menu_selector(MGCreatorLayer::onTheGame));
            auto menu = CCMenu::create();
            menu->addChild(btn);
            auto ws = CCDirector::sharedDirector()->getWinSize();
            menu->setPosition({ws.width - 40.f, 40.f});
            this->addChild(menu, 50);
        }
        return true;
    }

    void onTheGame(CCObject*) {
        CCDirector::sharedDirector()->pushScene(CCTransitionFade::create(0.4f, mg::LobbyLayer::scene()));
    }
};
