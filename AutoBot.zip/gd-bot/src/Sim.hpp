#pragma once
// Moteur de simulation + planificateur du bot autonome.
// C++ pur (aucune dépendance Geode) pour pouvoir le tester hors du jeu.
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <unordered_set>
#include <vector>

namespace ab {

// ---------------------------------------------------------------------------
// Constantes physiques. Les vitesses/accélérations sont en "unités GD par
// frame à 60 Hz" puis converties (x F). Elles sont APPROXIMATIVES : si le bot
// rate systématiquement un mode de jeu, c'est ici qu'il faut calibrer.
// ---------------------------------------------------------------------------
namespace K {
constexpr float DT = 1.f / 240.f;   // pas de physique de GD 2.2
constexpr float F = 60.f;
constexpr float FLOOR = 90.f;       // dessus du sol
constexpr float CEIL = 390.f;       // plafond des modes volants
constexpr float HAZ = 0.5f;         // hitbox joueur réduite face aux piques/scies
constexpr float SPEEDS[5] = {251.16f, 311.58f, 387.42f, 468.f, 576.f};

constexpr float CUBE_G = 0.958199f, CUBE_J = 11.180032f, CUBE_VMAX = 15.f;
constexpr float SHIP_UP = 0.8f, SHIP_DN = 0.6f, SHIP_VMAX = 8.f;
constexpr float BALL_G = 0.7f, BALL_VMAX = 15.f;
constexpr float UFO_G = 0.6f, UFO_J = 8.f, UFO_VMAX = 9.f;
constexpr float ROBOT_J = 10.f, ROBOT_BOOST = 0.25f;
constexpr float SWING_G = 0.7f, SWING_VMAX = 9.f;
constexpr float WAVE_R = 1.f, WAVE_RMINI = 2.f;  // pente verticale / vx

constexpr float PAD_V[3] = {16.f, 10.5f, 20.f};   // jaune, rose, rouge
constexpr float RING_V[3] = {11.2f, 7.5f, 14.5f}; // jaune, rose, rouge
}  // namespace K

enum Mode : uint8_t { Cube, Ship, Ball, Ufo, Wave, Robot, Spider, Swing };

// Objet de niveau : boîte (x0..x1, y0..y1). r > 0 => cercle (scie) centré dans la boîte.
struct O {
    float x0, y0, x1, y1, r;
    int k;
};

struct Level {
    enum { SOLID, SPIKE, SAW, PAD, ORB, PORTAL, N };
    std::vector<O> v[N];
    float ext[N] = {};

    void clear() {
        for (auto& a : v) a.clear();
        for (auto& e : ext) e = 0.f;
    }
    void add(int t, const O& o) {
        v[t].push_back(o);
        ext[t] = std::max(ext[t], o.x1 - o.x0);
    }
    void finish() {
        for (auto& a : v)
            std::sort(a.begin(), a.end(), [](const O& p, const O& q) { return p.x0 < q.x0; });
    }
    // Appelle f sur chaque objet de type t dont la boîte peut toucher [qx0, qx1].
    template <class F>
    void scan(int t, float qx0, float qx1, F&& f) const {
        const auto& a = v[t];
        auto it = std::lower_bound(a.begin(), a.end(), qx0 - ext[t],
                                   [](const O& o, float val) { return o.x0 < val; });
        for (; it != a.end() && it->x0 <= qx1; ++it) f(*it);
    }
};

struct St {
    float x = 0, y = 105, vy = 0, vx = 311.58f;
    Mode mode = Cube;
    bool flip = false, mini = false, onGround = true, hold = false, dead = false;
    int pIdx = 0, lastPad = -1, lastOrb = -1;
    float robotT = 0;
};

inline float dRect(float px0, float py0, float px1, float py1, const O& o) {
    float dx = std::max({0.f, o.x0 - px1, px0 - o.x1});
    float dy = std::max({0.f, o.y0 - py1, py0 - o.y1});
    return std::sqrt(dx * dx + dy * dy);
}

// Distance entre le rectangle joueur et un danger (négative = contact).
inline float hazardDist(float px0, float py0, float px1, float py1, const O& o) {
    if (o.r > 0.f) {
        float cx = (o.x0 + o.x1) * .5f, cy = (o.y0 + o.y1) * .5f;
        float dx = std::max({0.f, px0 - cx, cx - px1});
        float dy = std::max({0.f, py0 - cy, cy - py1});
        return std::sqrt(dx * dx + dy * dy) - o.r;
    }
    bool overlap = px1 > o.x0 && px0 < o.x1 && py1 > o.y0 && py0 < o.y1;
    return overlap ? -1.f : dRect(px0, py0, px1, py1, o);
}

inline void applyPortal(St& s, int k) {
    if (k < 8) {
        s.mode = (Mode)k;
        s.robotT = 0;
        if (k == Wave) s.vy = 0;
    } else if (k == 10) s.flip = false;
    else if (k == 11) s.flip = true;
    else if (k == 12) s.mini = true;
    else if (k == 13) s.mini = false;
    else if (k >= 20 && k <= 24) s.vx = K::SPEEDS[k - 20];
}

// Avance la simulation d'un pas (1/240 s). Renvoie false si le joueur meurt.
inline bool step(St& s, bool hold, const Level& L) {
    using namespace K;
    if (s.dead) return false;
    const bool edge = hold && !s.hold;
    s.hold = hold;
    const float h = s.mini ? 9.f : 15.f;

    // --- portails (triés par x) ---
    const auto& P = L.v[Level::PORTAL];
    while (s.pIdx < (int)P.size() && P[s.pIdx].x0 <= s.x) {
        const O& p = P[s.pIdx++];
        if (s.y + h >= p.y0 - 10.f && s.y - h <= p.y1 + 10.f) applyPortal(s, p.k);
    }
    float gs = s.flip ? -1.f : 1.f;

    // --- pads et orbes (sans effet sur la wave) ---
    if (s.mode != Wave) {
        const auto& PV = L.v[Level::PAD];
        L.scan(Level::PAD, s.x - h, s.x + h, [&](const O& o) {
            int id = int(&o - PV.data());
            if (id == s.lastPad) return;
            if (o.x1 < s.x - h || o.y1 < s.y - h || o.y0 > s.y + h) return;
            s.lastPad = id;
            if (o.k < 3) {
                s.vy = gs * PAD_V[o.k] * F;
                s.onGround = false;
            } else {
                s.flip = !s.flip;
                s.vy = 0;
                s.onGround = false;
            }
            gs = s.flip ? -1.f : 1.f;
        });
        if (edge) {
            const auto& OV = L.v[Level::ORB];
            bool used = false;
            L.scan(Level::ORB, s.x - h - 20.f, s.x + h + 20.f, [&](const O& o) {
                if (used) return;
                int id = int(&o - OV.data());
                if (id == s.lastOrb) return;
                if (o.x1 < s.x - h - 20.f || o.y1 < s.y - h - 20.f || o.y0 > s.y + h + 20.f) return;
                used = true;
                s.lastOrb = id;
                if (o.k < 3) {
                    s.vy = gs * RING_V[o.k] * F;
                } else if (o.k == 3) {
                    s.flip = !s.flip;
                    s.vy = 0;
                } else {
                    s.flip = !s.flip;
                    s.vy = (s.flip ? -1.f : 1.f) * 8.f * F;
                }
                s.onGround = false;
                gs = s.flip ? -1.f : 1.f;
            });
        }
    }

    // --- physique propre au mode ---
    bool symmetric = false;
    float vmax = 0;
    switch (s.mode) {
        case Cube:
            if (s.onGround && hold) {
                s.vy = gs * CUBE_J * F;
                s.onGround = false;
            } else s.vy -= gs * CUBE_G * F * F * DT;
            vmax = CUBE_VMAX;
            break;
        case Ship:
            s.vy += (hold ? gs * SHIP_UP : -gs * SHIP_DN) * F * F * DT;
            vmax = SHIP_VMAX; symmetric = true;
            break;
        case Ball:
            if (s.onGround && edge) {
                s.flip = !s.flip;
                gs = s.flip ? -1.f : 1.f;
                s.vy = 0;
                s.onGround = false;
            }
            s.vy -= gs * BALL_G * F * F * DT;
            vmax = BALL_VMAX;
            break;
        case Ufo:
            if (edge) s.vy = gs * UFO_J * F;
            else s.vy -= gs * UFO_G * F * F * DT;
            vmax = UFO_VMAX; symmetric = true;
            break;
        case Wave:
            s.vy = (hold ? 1.f : -1.f) * s.vx * (s.mini ? WAVE_RMINI : WAVE_R);
            break;
        case Robot:
            if (s.onGround && edge) {
                s.vy = gs * ROBOT_J * F;
                s.robotT = ROBOT_BOOST;
                s.onGround = false;
            } else if (hold && s.robotT > 0.f) {
                s.vy = gs * ROBOT_J * F;
                s.robotT -= DT;
            } else {
                s.robotT = 0;
                s.vy -= gs * CUBE_G * F * F * DT;
            }
            vmax = CUBE_VMAX;
            break;
        case Spider:
            if (s.onGround && edge) {
                float target;
                if (!s.flip) {  // on est en bas : on file vers le plafond / le premier bloc au-dessus
                    target = CEIL - h;
                    L.scan(Level::SOLID, s.x - h, s.x + h, [&](const O& o) {
                        if (o.x1 > s.x - h && o.x0 < s.x + h && o.y0 > s.y + h) target = std::min(target, o.y0 - h);
                    });
                } else {
                    target = FLOOR + h;
                    L.scan(Level::SOLID, s.x - h, s.x + h, [&](const O& o) {
                        if (o.x1 > s.x - h && o.x0 < s.x + h && o.y1 < s.y - h) target = std::max(target, o.y1 + h);
                    });
                }
                s.flip = !s.flip;
                s.y = target;
                s.vy = 0;
                s.onGround = true;
            } else s.vy -= gs * CUBE_G * F * F * DT;
            vmax = CUBE_VMAX;
            break;
        case Swing:
            if (edge) s.flip = !s.flip;
            gs = s.flip ? -1.f : 1.f;
            s.vy -= gs * SWING_G * F * F * DT;
            vmax = SWING_VMAX; symmetric = true;
            break;
    }
    if (s.mode != Wave) {
        const float cap = vmax * F;
        gs = s.flip ? -1.f : 1.f;
        if (s.vy * gs < -cap) s.vy = -gs * cap;
        if (symmetric && s.vy * gs > cap) s.vy = gs * cap;
    }

    // --- déplacement horizontal ---
    s.x += s.vx * DT;
    bool deadly = false;
    L.scan(Level::SOLID, s.x - h, s.x + h, [&](const O& o) {
        if (o.x1 > s.x - h + .01f && o.x0 < s.x + h - .01f && o.y1 > s.y - h + 8.f && o.y0 < s.y + h - 8.f)
            deadly = true;
    });
    if (deadly) { s.dead = true; return false; }

    // --- déplacement vertical + sol/plafond/blocs ---
    s.y += s.vy * DT;
    bool grounded = false;
    L.scan(Level::SOLID, s.x - h, s.x + h, [&](const O& o) {
        if (!(o.x1 > s.x - h + .5f && o.x0 < s.x + h - .5f && o.y1 > s.y - h && o.y0 < s.y + h)) return;
        if (s.mode == Wave) { deadly = true; return; }
        if (s.vy < 0.f || (s.vy == 0.f && (o.y1 - (s.y - h)) < ((s.y + h) - o.y0))) {
            s.y = o.y1 + h;
            if (!s.flip) grounded = true;
        } else {
            s.y = o.y0 - h;
            if (s.flip) grounded = true;
        }
        s.vy = 0;
    });
    if (deadly) { s.dead = true; return false; }

    const float ceilY = ((s.mode == Cube || s.mode == Robot) && !s.flip) ? 1e6f : CEIL;
    if (s.y - h < FLOOR) {
        s.y = FLOOR + h;
        if (s.vy < 0) s.vy = 0;
        if (!s.flip) grounded = true;
    }
    if (s.y + h > ceilY) {
        s.y = ceilY - h;
        if (s.vy > 0) s.vy = 0;
        if (s.flip) grounded = true;
    }
    s.onGround = grounded;

    // --- dangers (hitbox joueur réduite) ---
    const float hh = h * HAZ;
    bool hit = false;
    auto chk = [&](const O& o) {
        if (hazardDist(s.x - hh, s.y - hh, s.x + hh, s.y + hh, o) < 0.f) hit = true;
    };
    L.scan(Level::SPIKE, s.x - hh, s.x + hh, chk);
    L.scan(Level::SAW, s.x - hh, s.x + hh, chk);
    if (hit) { s.dead = true; return false; }
    return true;
}

// Marge de sécurité : distance au danger le plus proche (plafonnée).
inline float margin(const St& s, const Level& L) {
    const float h = s.mini ? 9.f : 15.f, hh = h * K::HAZ;
    float best = 80.f;
    auto chk = [&](const O& o) {
        best = std::min(best, hazardDist(s.x - hh, s.y - hh, s.x + hh, s.y + hh, o));
    };
    L.scan(Level::SPIKE, s.x - hh - 80.f, s.x + hh + 80.f, chk);
    L.scan(Level::SAW, s.x - hh - 80.f, s.x + hh + 80.f, chk);
    return best;
}

inline int hazardsAhead(const Level& L, float x, float dist) {
    int n = 0;
    auto c = [&](const O& o) { if (o.x1 >= x) ++n; };
    L.scan(Level::SPIKE, x, x + dist, c);
    L.scan(Level::SAW, x, x + dist, c);
    return n;
}

struct PlanRes {
    std::vector<uint8_t> acts;  // une action (maintenir ou non) par "stride" de pas
    int depth = 0;              // nombre de strides survécus par la meilleure branche
};

// Recherche en faisceau : teste "maintenir" / "relâcher" sur H strides de `stride` pas.
inline PlanRes plan(const Level& L, const St& s0, int W, int H, int stride) {
    struct N { St s; int parent; uint8_t act; float score; };
    std::vector<N> pool;
    pool.reserve((size_t)W * 2 * H + 2);
    pool.push_back({s0, -1, (uint8_t)s0.hold, 0.f});
    std::vector<int> cur{0}, nxt;
    const float mid = (K::FLOOR + K::CEIL) * .5f;
    int depth = 0;

    for (int layer = 0; layer < H; ++layer) {
        nxt.clear();
        for (int ci : cur) {
            for (int a = 0; a < 2; ++a) {
                N n = pool[ci];
                n.parent = ci;
                bool alive = true;
                for (int k = 0; k < stride && alive; ++k) alive = step(n.s, a != 0, L);
                if (!alive) continue;
                n.act = (uint8_t)a;
                n.score = margin(n.s, L) + (a == pool[ci].act ? 0.5f : 0.f);
                if (n.s.mode != Cube && n.s.mode != Robot) n.score -= std::fabs(n.s.y - mid) * 0.01f;
                pool.push_back(n);
                nxt.push_back((int)pool.size() - 1);
            }
        }
        if (nxt.empty()) break;  // toutes les branches meurent : on garde la couche précédente
        std::sort(nxt.begin(), nxt.end(), [&](int p, int q) { return pool[p].score > pool[q].score; });
        std::unordered_set<int64_t> seen;
        std::vector<int> kept;
        for (int i : nxt) {
            const St& s = pool[i].s;
            int64_t key = ((int64_t)(int)std::floor(s.y / 4.f) * 1315423911LL) ^
                          ((int64_t)(int)std::floor(s.vy / 40.f) * 2654435761LL) ^
                          ((int64_t)s.mode << 3) ^ ((int64_t)s.hold << 1) ^ (int64_t)s.flip;
            if (seen.insert(key).second) kept.push_back(i);
            if ((int)kept.size() >= W) break;
        }
        cur = std::move(kept);
        ++depth;
    }

    PlanRes r;
    r.depth = depth;
    for (int i = cur[0]; pool[i].parent != -1; i = pool[i].parent) r.acts.push_back(pool[i].act);
    std::reverse(r.acts.begin(), r.acts.end());
    return r;
}

}  // namespace ab
