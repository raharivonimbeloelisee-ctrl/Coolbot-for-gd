// AutoBot : bot autonome pour Geometry Dash (Geode, Android).
// 1. Au chargement du niveau, il scanne tous les objets (piques/scies avec hitbox
//    exacte, blocs/orbes/pads/portails en simples rectangles).
// 2. Pendant la partie, il planifie en avant (recherche en faisceau sur une
//    simulation maison des 8 modes de jeu) et injecte les appuis.
#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>

#include "Sim.hpp"

using namespace geode::prelude;

namespace G {
inline ab::Level L;
inline std::vector<uint8_t> acts;
inline size_t idx = 0;
inline int stride = 4, stepIn = 0, sinceReplan = 0, replanSteps = 12;
inline bool holding = false, inject = false;

inline bool enabled() { return Mod::get()->getSettingValue<bool>("enabled"); }
inline void resetPlan() { acts.clear(); idx = 0; stepIn = 0; sinceReplan = 0; }

// Lit tous les objets du niveau une seule fois.
inline void buildLevel(GJBaseGameLayer* gl) {
    using namespace ab;
    L.clear();
    for (auto* obj : CCArrayExt<GameObject*>(gl->m_objects)) {
        if (!obj) continue;
        auto r = obj->getObjectRect();
        O o{r.getMinX(), r.getMinY(), r.getMaxX(), r.getMaxY(), 0.f, 0};
        int id = obj->m_objectID;

        // portails de vitesse (objets "modificateurs")
        int sp = id == 200 ? 20 : id == 201 ? 21 : id == 202 ? 22 : id == 203 ? 23 : id == 1334 ? 24 : -1;
        if (sp >= 0) { o.k = sp; L.add(Level::PORTAL, o); continue; }

        switch (obj->m_objectType) {
            case GameObjectType::Hazard:
                if (obj->m_objectRadius > 0.f) { o.r = obj->m_objectRadius; L.add(Level::SAW, o); }
                else L.add(Level::SPIKE, o);
                break;
            case GameObjectType::Solid:
            case GameObjectType::Slope:  // pentes approximées par leur rectangle
                L.add(Level::SOLID, o); break;
            case GameObjectType::YellowJumpPad: o.k = 0; L.add(Level::PAD, o); break;
            case GameObjectType::PinkJumpPad: o.k = 1; L.add(Level::PAD, o); break;
            case GameObjectType::RedJumpPad: o.k = 2; L.add(Level::PAD, o); break;
            case GameObjectType::GravityPad: o.k = 3; L.add(Level::PAD, o); break;
            case GameObjectType::YellowJumpRing: o.k = 0; L.add(Level::ORB, o); break;
            case GameObjectType::PinkJumpRing: o.k = 1; L.add(Level::ORB, o); break;
            case GameObjectType::RedJumpRing: o.k = 2; L.add(Level::ORB, o); break;
            case GameObjectType::GravityRing: o.k = 3; L.add(Level::ORB, o); break;
            case GameObjectType::GreenRing: o.k = 4; L.add(Level::ORB, o); break;
            case GameObjectType::CubePortal: o.k = Cube; L.add(Level::PORTAL, o); break;
            case GameObjectType::ShipPortal: o.k = Ship; L.add(Level::PORTAL, o); break;
            case GameObjectType::BallPortal: o.k = Ball; L.add(Level::PORTAL, o); break;
            case GameObjectType::UfoPortal: o.k = Ufo; L.add(Level::PORTAL, o); break;
            case GameObjectType::WavePortal: o.k = Wave; L.add(Level::PORTAL, o); break;
            case GameObjectType::RobotPortal: o.k = Robot; L.add(Level::PORTAL, o); break;
            case GameObjectType::SpiderPortal: o.k = Spider; L.add(Level::PORTAL, o); break;
            case GameObjectType::SwingPortal: o.k = Swing; L.add(Level::PORTAL, o); break;
            case GameObjectType::NormalGravityPortal: o.k = 10; L.add(Level::PORTAL, o); break;
            case GameObjectType::InverseGravityPortal: o.k = 11; L.add(Level::PORTAL, o); break;
            case GameObjectType::MiniSizePortal: o.k = 12; L.add(Level::PORTAL, o); break;
            case GameObjectType::RegularSizePortal: o.k = 13; L.add(Level::PORTAL, o); break;
            default: break;
        }
    }
    L.finish();
    log::info("AutoBot: {} solides, {} piques, {} scies, {} pads, {} orbes, {} portails",
              L.v[ab::Level::SOLID].size(), L.v[ab::Level::SPIKE].size(), L.v[ab::Level::SAW].size(),
              L.v[ab::Level::PAD].size(), L.v[ab::Level::ORB].size(), L.v[ab::Level::PORTAL].size());
}

// État réel du joueur -> état de simulation.
inline ab::St readState(PlayerObject* p) {
    using namespace ab;
    St s;
    auto pos = p->getPosition();
    s.x = pos.x;
    s.y = pos.y;
    s.vy = (float)p->m_yVelocity * K::F;
    s.flip = p->m_isUpsideDown;
    s.mini = std::fabs(p->getScaleX()) < 0.8f;
    s.onGround = p->m_isOnGround;
    s.hold = holding;
    s.mode = p->m_isShip ? Ship : p->m_isBall ? Ball : p->m_isBird ? Ufo : p->m_isDart ? Wave
           : p->m_isRobot ? Robot : p->m_isSpider ? Spider : p->m_isSwing ? Swing : Cube;
    float spd = p->m_playerSpeed;
    int si = spd < 0.8f ? 0 : spd < 1.f ? 1 : spd < 1.2f ? 2 : spd < 1.45f ? 3 : 4;
    s.vx = K::SPEEDS[si];
    const auto& P = L.v[Level::PORTAL];
    s.pIdx = (int)(std::lower_bound(P.begin(), P.end(), s.x - 1.f,
                                     [](const O& o, float v) { return o.x0 < v; }) - P.begin());
    return s;
}

// Choisit la précision selon la difficulté de la zone (waves et passages serrés = plus fin).
inline void replan(PlayerObject* p) {
    auto s = readState(p);
    int W = 20, H = 40;
    stride = 4; replanSteps = 12;
    if (s.mode == ab::Wave) { W = 48; H = 70; stride = 2; replanSteps = 8; }
    else if (ab::hazardsAhead(L, s.x, 180.f) > 4) { W = 40; H = 55; stride = 2; replanSteps = 8; }
    auto r = ab::plan(L, s, W, H, stride);
    acts = std::move(r.acts);
    idx = 0; stepIn = 0; sinceReplan = 0;
}
}  // namespace G

class $modify(AutoBaseLayer, GJBaseGameLayer) {
    // Pendant que le bot joue, on ignore les vrais appuis du joueur.
    void handleButton(bool down, int button, bool isPlayer1) {
        if (G::enabled() && !G::inject && PlayLayer::get()) return;
        GJBaseGameLayer::handleButton(down, button, isPlayer1);
    }

    void processCommands(float dt) {
        auto pl = PlayLayer::get();
        if (pl && static_cast<GJBaseGameLayer*>(pl) == this && G::enabled() && m_player1 && !m_player1->m_isDead) {
            if (G::acts.empty() || G::idx >= G::acts.size() || G::sinceReplan >= G::replanSteps)
                G::replan(m_player1);

            bool want = !G::acts.empty() ? G::acts[G::idx] != 0 : G::holding;
            if (want != G::holding) {
                G::inject = true;
                GJBaseGameLayer::handleButton(want, 1, true);
                G::inject = false;
                G::holding = want;
            }
            ++G::sinceReplan;
            if (++G::stepIn >= G::stride) { G::stepIn = 0; ++G::idx; }
        }
        GJBaseGameLayer::processCommands(dt);
    }
};

// Bouton dans le menu de pause pour activer / désactiver le bot.
class $modify(AutoPauseLayer, PauseLayer) {
    void customSetup() {
        PauseLayer::customSetup();

        auto toggler = CCMenuItemToggler::createWithStandardSprites(
            this, menu_selector(AutoPauseLayer::onToggleBot), 0.7f);
        toggler->toggle(G::enabled());

        auto label = CCLabelBMFont::create("AutoBot", "bigFont.fnt");
        label->setScale(0.5f);
        label->setAnchorPoint({0.f, 0.5f});
        label->setPosition({24.f, 0.f});

        auto menu = CCMenu::create();
        menu->setPosition({30.f, 30.f});
        menu->addChild(toggler);
        menu->addChild(label);
        this->addChild(menu);
    }

    void onToggleBot(CCObject* sender) {
        // Le rappel est appelé avant que le bouton ne change d'état.
        bool now = !static_cast<CCMenuItemToggler*>(sender)->isToggled();
        Mod::get()->setSettingValue<bool>("enabled", now);
        G::resetPlan();
        if (!now && G::holding) {  // on relâche un appui laissé par le bot
            if (auto pl = PlayLayer::get()) {
                G::inject = true;
                pl->handleButton(false, 1, true);
                G::inject = false;
            }
            G::holding = false;
        }
    }
};

class $modify(AutoPlayLayer, PlayLayer) {
    void setupHasCompleted() {
        PlayLayer::setupHasCompleted();
        G::buildLevel(this);
        G::resetPlan();
        G::holding = false;
    }
    void resetLevel() {
        PlayLayer::resetLevel();
        G::resetPlan();
        G::holding = false;
    }
};
