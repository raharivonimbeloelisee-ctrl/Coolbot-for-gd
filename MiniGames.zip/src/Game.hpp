#pragma once
// Partie de rythme : 4 colonnes, cibles en haut, flèches qui montent depuis le bas.
#include <Geode/Geode.hpp>
#include <Geode/fmod/fmod.hpp>

#include <atomic>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <filesystem>
#include <memory>
#include <thread>
#include <vector>

#include "Analyzer.hpp"

using namespace geode::prelude;

namespace mg {

inline void say(char const* text, bool error = true) {
    Notification::create(text, error ? NotificationIcon::Error : NotificationIcon::Success, 2.f)->show();
}

// Redimensionne un nœud à une taille donnée (en points).
inline void fit(CCNode* n, float w, float h) {
    auto s = n->getContentSize();
    if (s.width > 0.f && s.height > 0.f) { n->setScaleX(w / s.width); n->setScaleY(h / s.height); }
}

// Flèche pré-tournée selon la colonne (0 gauche, 1 bas, 2 haut, 3 droite).
inline CCSprite* arrowSprite(int lane) {
    switch (lane) {
        case 0: return CCSprite::create("jeu_fleche_gauche.png"_spr);
        case 1: return CCSprite::create("jeu_fleche_bas.png"_spr);
        case 2: return CCSprite::create("jeu_fleche_haut.png"_spr);
        default: return CCSprite::create("jeu_fleche_droite.png"_spr);
    }
}

// ---------- décodage + analyse (thread de fond) ----------

struct Job {
    std::atomic<int> state{0};  // 0 en cours, 1 terminé, 2 échec
    std::vector<rb::Note> notes;
};

inline bool decodeMono(FMOD::System* sys, std::string const& path, std::vector<float>& mono, int& rate) {
    FMOD::Sound* snd = nullptr;
    if (sys->createSound(path.c_str(), FMOD_OPENONLY, nullptr, &snd) != FMOD_OK || !snd) return false;
    FMOD_SOUND_TYPE ty;
    FMOD_SOUND_FORMAT fmt;
    int ch = 0, bits = 0;
    snd->getFormat(&ty, &fmt, &ch, &bits);
    float fr = 44100.f;
    int pr = 0;
    snd->getDefaults(&fr, &pr);
    rate = (int)fr;
    bool ok = (fmt == FMOD_SOUND_FORMAT_PCM16 || fmt == FMOD_SOUND_FORMAT_PCMFLOAT) && ch > 0 && rate > 8000;
    if (ok) {
        size_t bps = fmt == FMOD_SOUND_FORMAT_PCM16 ? 2 : 4;
        size_t maxFrames = (size_t)rate * 300;  // 5 minutes maximum
        std::vector<char> buf(65536);
        while (mono.size() < maxFrames) {
            unsigned rd = 0;
            auto r = snd->readData(buf.data(), (unsigned)buf.size(), &rd);
            if (rd == 0 || (r != FMOD_OK && r != FMOD_ERR_FILE_EOF)) break;
            size_t frames = rd / (bps * ch);
            for (size_t i = 0; i < frames; ++i) {
                float sum = 0.f;
                for (int c = 0; c < ch; ++c) {
                    if (fmt == FMOD_SOUND_FORMAT_PCM16) {
                        int16_t v;
                        std::memcpy(&v, buf.data() + (i * ch + c) * 2, 2);
                        sum += v / 32768.f;
                    } else {
                        float v;
                        std::memcpy(&v, buf.data() + (i * ch + c) * 4, 4);
                        sum += v;
                    }
                }
                mono.push_back(sum / ch);
            }
            if (r == FMOD_ERR_FILE_EOF) break;
        }
    }
    snd->release();
    return ok && mono.size() > 4096;
}

struct Chart {
    float t;
    int lane;
    int st = 0;  // 0 en attente, 1 touchée, 2 ratée
    bool oppHit = false;
    bool oppDone = false;
    CCSprite* spr = nullptr;   // flèche du joueur
    CCSprite* ospr = nullptr;  // flèche de l'adversaire
};

struct Particle {
    CCSprite* s;
    float vx, vy, life;
};

class GameLayer : public CCLayer {
public:
    int m_songId = 0;
    std::string m_path;
    int m_diff = 1;
    int m_oppIdx = 0;

    std::shared_ptr<Job> m_job;
    int m_phase = 0;  // 0 analyse, 1 jeu, 2 résultats
    std::vector<Chart> m_notes;
    size_t m_head = 0;
    float m_t = -3.f, m_endT = 0.f;
    bool m_started = false, m_usedFallback = false;
    FMOD::Sound* m_sound = nullptr;
    FMOD::Channel* m_chan = nullptr;
    unsigned m_lenMs = 0;

    int m_score = 0, m_combo = 0, m_maxCombo = 0, m_cP = 0, m_cG = 0, m_cO = 0, m_cM = 0;
    int m_oScore = 0, m_oCombo = 0;

    CCSize m_ws;
    float m_LS = 60.f, m_recY = 0.f, m_speed = 1.f, m_travel = 1.4f;
    float m_cx = 0.f, m_ox = 0.f, m_os = 0.5f;
    CCNode* m_world = nullptr;
    CCSprite* m_recept[4] = {};
    CCSprite* m_flash[4] = {};
    float m_flashT[4] = {};
    CCSprite* m_padBtn[4] = {};
    bool m_padDown[4] = {};
    float m_judgeT = 0.f;
    CCLabelBMFont *m_sL = nullptr, *m_oL = nullptr, *m_cL = nullptr, *m_jL = nullptr, *m_cd = nullptr;
    CCNode* m_result = nullptr;
    std::vector<Particle> m_parts;


    static CCScene* scene(int songId, std::string path, int diff, int oppIdx) {
        auto l = new GameLayer();
        l->m_songId = songId; l->m_path = std::move(path); l->m_diff = diff; l->m_oppIdx = oppIdx;
        if (l->init()) l->autorelease(); else { delete l; return nullptr; }
        auto s = CCScene::create();
        s->addChild(l);
        return s;
    }

    float laneX(int lane) const { return m_cx + (lane - 1.5f) * m_LS * 1.1f; }
    float oLaneX(int lane) const { return m_ox + (lane - 1.5f) * m_LS * 1.1f * m_os; }

    bool init() override {
        if (!CCLayer::init()) return false;
        m_ws = CCDirector::sharedDirector()->getWinSize();
        float W = m_ws.width, H = m_ws.height;
        m_LS = std::clamp(H * 0.105f, 48.f, 84.f);
        m_recY = H - m_LS * 1.5f;               // cibles en haut
        m_speed = (m_recY + m_LS) / m_travel;   // les flèches montent depuis le bas
        m_cx = W * 0.5f;
        m_ox = W * 0.86f;

        auto bg = CCSprite::create("jeu_fond.png"_spr);
        bg->setPosition({W / 2, H / 2}); fit(bg, W, H);
        this->addChild(bg, -2);

        m_world = CCNode::create();
        this->addChild(m_world, 0);

        for (int l = 0; l < 4; ++l) {
            auto c = CCSprite::create("jeu_cible.png"_spr);
            c->setPosition({laneX(l), m_recY}); fit(c, m_LS * 0.95f, m_LS * 0.95f);
            m_world->addChild(c, 1);
            m_recept[l] = c;
            auto ar = arrowSprite(l);
            ar->setPosition({laneX(l), m_recY}); fit(ar, m_LS * 0.55f, m_LS * 0.55f);
            m_world->addChild(ar, 2);
            auto fl = CCSprite::create("jeu_eclat_touche.png"_spr);
            fl->setPosition({laneX(l), m_recY}); fit(fl, m_LS * 1.5f, m_LS * 1.5f);
            fl->setOpacity(0);
            m_world->addChild(fl, 3);
            m_flash[l] = fl;
            // boutons tactiles en bas
            auto b = CCSprite::create("jeu_cible.png"_spr);
            b->setPosition({laneX(l), m_LS * 0.9f}); fit(b, m_LS * 0.95f, m_LS * 0.95f);
            m_world->addChild(b, 1);
            m_padBtn[l] = b;
        }

        // cibles adverses plus petites à droite
        for (int l = 0; l < 4; ++l) {
            auto c = CCSprite::create("jeu_cible.png"_spr);
            c->setPosition({oLaneX(l), m_recY}); fit(c, m_LS * 0.95f * m_os, m_LS * 0.95f * m_os);
            m_world->addChild(c, 1);
        }

        // HUD
        auto band = CCSprite::create("jeu_bandeau_score.png"_spr);
        band->setPosition({W / 2, H - 22.f}); fit(band, W * 0.36f, 40.f);
        this->addChild(band, 4);
        m_sL = CCLabelBMFont::create("0", "bigFont.fnt");
        m_sL->setScale(0.45f); m_sL->setAnchorPoint({1.f, 0.5f}); m_sL->setPosition({W * 0.5f - 10.f, H - 22.f});
        this->addChild(m_sL, 5);
        m_oL = CCLabelBMFont::create("0", "bigFont.fnt");
        m_oL->setScale(0.45f); m_oL->setAnchorPoint({0.f, 0.5f}); m_oL->setPosition({W * 0.5f + 10.f, H - 22.f});
        this->addChild(m_oL, 5);
        m_cL = CCLabelBMFont::create("", "goldFont.fnt");
        m_cL->setScale(0.6f); m_cL->setPosition({m_cx, m_recY - m_LS * 1.25f});
        this->addChild(m_cL, 5);

        // texte de jugement dans son panneau
        auto jp = CCSprite::create("jeu_panneau_jugement.png"_spr);
        jp->setPosition({m_cx, H * 0.5f}); fit(jp, m_LS * 4.4f, m_LS * 1.2f);
        jp->setOpacity(0);
        this->addChild(jp, 5);
        m_jL = CCLabelBMFont::create("", "bigFont.fnt");
        m_jL->setScale(0.55f); m_jL->setPosition({m_cx, H * 0.5f});
        m_jL->setOpacity(0);
        this->addChild(m_jL, 6);
        m_judgeT = 0.f;

        m_cd = CCLabelBMFont::create("", "bigFont.fnt");
        m_cd->setScale(1.4f); m_cd->setPosition({W / 2, H * 0.3f});
        this->addChild(m_cd, 6);


        FMODAudioEngine::sharedEngine()->pauseAllMusic(true);

        m_job = std::make_shared<Job>();
        auto job = m_job;
        auto sys = FMODAudioEngine::sharedEngine()->m_system;
        std::string path = m_path;
        float sens = (float)Mod::get()->getSettingValue<double>("sensitivity");
        std::thread([job, sys, path, sens]() {
            std::vector<float> mono;
            int rate = 44100;
            bool ok = false;
            try {
                if (decodeMono(sys, path, mono, rate)) {
                    rb::Params p;
                    p.sensitivity = sens;
                    job->notes = rb::analyze(mono, rate, p);
                    ok = job->notes.size() >= 10;
                }
            } catch (...) {}
            job->state = ok ? 1 : 2;
        }).detach();

        m_cd->setString("Analyse...");
        this->setTouchEnabled(true);
        this->setKeypadEnabled(true);
        this->scheduleUpdate();
        return true;
    }


    void keyBackClicked() override { quit(); }

    void quit() {
        stopMusic();
        FMODAudioEngine::sharedEngine()->resumeAllMusic();
        CCDirector::sharedDirector()->popScene();
    }

    void stopMusic() {
        if (m_chan) { m_chan->stop(); m_chan = nullptr; }
    }

    void onExit() override {
        stopMusic();
        if (m_sound) { m_sound->release(); m_sound = nullptr; }
        CCLayer::onExit();
    }

    void prepare() {
        auto sys = FMODAudioEngine::sharedEngine()->m_system;
        if (!m_sound) {
            if (sys->createStream(m_path.c_str(), FMOD_DEFAULT, nullptr, &m_sound) != FMOD_OK || !m_sound) {
                say("Impossible de lire la musique.");
                quit();
                return;
            }
            m_sound->getLength(&m_lenMs, FMOD_TIMEUNIT_MS);
        }
        std::vector<rb::Note> src;
        if (m_job && m_job->state == 1) src = m_job->notes;
        else {
            m_usedFallback = true;
            src = rb::fromBpm((float)Mod::get()->getSettingValue<int64_t>("fallback_bpm"), m_lenMs / 1000.f, 0.5f);
            say("Analyse impossible : mode tempo (BPM).");
        }
        std::srand((unsigned)std::time(nullptr));
        static const float ACC[3] = {0.60f, 0.80f, 0.95f};
        m_notes.clear();
        for (auto& n : src) {
            Chart c;
            c.t = n.t; c.lane = n.lane;
            c.oppHit = (std::rand() % 1000) / 1000.f < ACC[std::clamp(m_diff, 0, 2)];
            m_notes.push_back(c);
        }
        m_endT = m_notes.empty() ? 5.f : m_notes.back().t + 2.5f;
        startRun();
    }

    void clearSprites() {
        for (auto& n : m_notes) {
            if (n.spr) { n.spr->removeFromParent(); n.spr = nullptr; }
            if (n.ospr) { n.ospr->removeFromParent(); n.ospr = nullptr; }
        }
        for (auto& p : m_parts) p.s->removeFromParent();
        m_parts.clear();
    }

    void startRun() {
        stopMusic();
        clearSprites();
        for (auto& n : m_notes) { n.st = 0; n.oppDone = false; }
        m_head = 0; m_t = -3.f; m_started = false;
        m_score = m_combo = m_maxCombo = m_cP = m_cG = m_cO = m_cM = 0;
        m_oScore = m_oCombo = 0;
        if (m_result) { m_result->removeFromParent(); m_result = nullptr; }
        auto sys = FMODAudioEngine::sharedEngine()->m_system;
        sys->playSound(m_sound, nullptr, true, &m_chan);
        m_phase = 1;
    }

    float disp() {
        return m_t - (float)Mod::get()->getSettingValue<int64_t>("audio_offset") / 1000.f;
    }

    void judge(char const* txt, ccColor3B col) {
        m_jL->setString(txt);
        m_jL->setColor(col);
        m_jL->setOpacity(255);
        m_judgeT = 0.5f;
    }

    void burst(float x, float y, int n, bool white) {
        for (int i = 0; i < n; ++i) {
            auto s = CCSprite::create(white ? "jeu_particule_blanche.png"_spr : "jeu_particule_rouge.png"_spr);
            s->setPosition({x, y}); fit(s, m_LS * 0.2f, m_LS * 0.2f);
            m_world->addChild(s, 4);
            float a = (float)i / n * 6.2832f + (std::rand() % 100) / 100.f;
            float v = m_LS * (2.f + (std::rand() % 100) / 50.f);
            m_parts.push_back({s, std::cos(a) * v, std::sin(a) * v, 0.45f});
        }
    }

    void hitLane(int lane) {
        m_flashT[lane] = 0.15f;
        float d = disp();
        int best = -1;
        float bestAbs = 0.13f;
        for (size_t j = m_head; j < m_notes.size() && m_notes[j].t < d + 0.2f; ++j) {
            auto& n = m_notes[j];
            if (n.st != 0 || n.lane != lane) continue;
            float a = std::fabs(n.t - d);
            if (a < bestAbs) { bestAbs = a; best = (int)j; }
        }
        if (best < 0) return;  // appui dans le vide : pas de pénalité
        auto& n = m_notes[best];
        n.st = 1;
        if (n.spr) { n.spr->removeFromParent(); n.spr = nullptr; }
        burst(laneX(lane), m_recY, 8, true);
        if (bestAbs <= 0.045f) { m_score += 350; ++m_cP; judge("PARFAIT", {255, 230, 120}); }
        else if (bestAbs <= 0.09f) { m_score += 200; ++m_cG; judge("BIEN", {140, 255, 150}); }
        else { m_score += 100; ++m_cO; judge("OK", {160, 230, 255}); }
        ++m_combo;
        m_maxCombo = std::max(m_maxCombo, m_combo);
    }

    void ccTouchesBegan(CCSet* touches, CCEvent*) override {
        if (m_phase != 1 || m_t < -0.5f) return;
        for (auto it = touches->begin(); it != touches->end(); ++it) {
            auto t = static_cast<CCTouch*>(*it);
            auto p = CCDirector::sharedDirector()->convertToGL(t->getLocationInView());
            for (int l = 0; l < 4; ++l) {
                if (std::fabs(p.x - laneX(l)) < m_LS * 0.6f && std::fabs(p.y - m_LS * 0.9f) < m_LS * 0.6f) {
                    hitLane(l);
                }
            }
        }
    }

    void update(float dt) override {
        if (m_phase == 0) {
            if (m_job && m_job->state != 0) prepare();
            return;
        }
        if (m_phase != 1) return;

        m_t += dt;
        if (!m_started && m_t >= 0.f) {
            m_started = true;
            if (m_chan) m_chan->setPaused(false);
        }
        if (m_started && m_chan) {
            unsigned ms = 0;
            if (m_chan->getPosition(&ms, FMOD_TIMEUNIT_MS) == FMOD_OK) {
                float a = ms / 1000.f;
                if (std::fabs(a - m_t) > 0.05f) m_t = a;
                else m_t += (a - m_t) * 0.1f;
            }
        }
        m_cd->setString(m_t < 0.f ? std::to_string((int)std::ceil(-m_t)).c_str() : "");

        float d = disp();
        static const int OPP_PTS[3] = {350, 350, 200};
        for (size_t j = m_head; j < m_notes.size() && m_notes[j].t < d + 1.5f; ++j) {
            auto& n = m_notes[j];
            // ratés
            if (n.st == 0 && n.t < d - 0.13f) {
                n.st = 2; ++m_cM; m_combo = 0;
                if (n.spr) { n.spr->removeFromParent(); n.spr = nullptr; }
                judge("RATÉ", {255, 110, 110});
            }
            // adversaire
            if (!n.oppDone && n.t <= d) {
                n.oppDone = true;
                if (n.oppHit) { m_oScore += OPP_PTS[std::rand() % 3]; ++m_oCombo; }
                else m_oCombo = 0;
                if (n.ospr) { n.ospr->removeFromParent(); n.ospr = nullptr; }
            }
            // création / mise à jour des sprites visibles
            float yy = m_recY - (n.t - d) * m_speed;
            if (n.st == 0 && yy < m_ws.height + 40.f && yy > m_recY - m_LS * 1.6f - m_LS) {
                if (!n.spr) {
                    n.spr = arrowSprite(n.lane);
                    fit(n.spr, m_LS * 0.9f, m_LS * 0.9f);
                    m_world->addChild(n.spr, 3);
                }
                n.spr->setPosition({laneX(n.lane), yy});
            } else if (n.st == 0 && yy <= m_recY - m_LS * 1.6f - m_LS && n.spr) {
                n.spr->removeFromParent(); n.spr = nullptr;
            }
            if (!n.oppDone && n.st >= 0) {
                if (!n.ospr && yy < m_ws.height + 40.f && yy > m_recY - m_LS * 1.6f - m_LS) {
                    n.ospr = arrowSprite(n.lane);
                    fit(n.ospr, m_LS * 0.9f * m_os, m_LS * 0.9f * m_os);
                    m_world->addChild(n.ospr, 3);
                }
                if (n.ospr) n.ospr->setPosition({oLaneX(n.lane), yy});
            }
        }
        while (m_head < m_notes.size() && m_notes[m_head].st != 0 && m_notes[m_head].oppDone) ++m_head;

        // éclats, particules
        for (int l = 0; l < 4; ++l) {
            if (m_flashT[l] > 0.f) {
                m_flashT[l] -= dt;
                m_flash[l]->setOpacity((GLubyte)std::clamp(m_flashT[l] / 0.15f * 255.f, 0.f, 255.f));
            }
        }
        for (size_t i = 0; i < m_parts.size();) {
            auto& p = m_parts[i];
            p.life -= dt;
            auto pos = p.s->getPosition();
            p.s->setPosition({pos.x + p.vx * dt, pos.y + p.vy * dt});
            p.s->setOpacity((GLubyte)std::clamp(p.life / 0.45f * 255.f, 0.f, 255.f));
            if (p.life <= 0.f) { p.s->removeFromParent(); m_parts[i] = m_parts.back(); m_parts.pop_back(); }
            else ++i;
        }

        // HUD
        m_sL->setString(std::to_string(m_score).c_str());
        m_oL->setString(std::to_string(m_oScore).c_str());
        m_cL->setString(m_combo >= 2 ? (std::to_string(m_combo) + " COMBO").c_str() : "");
        if (m_judgeT > 0.f) {
            m_judgeT -= dt;
            if (m_judgeT <= 0.f) { m_jL->setOpacity(0); }
        }

        if (d > m_endT) finish();
    }

    void finish() {
        if (m_phase == 2) return;
        m_phase = 2;
        stopMusic();
        clearSprites();
        float W = m_ws.width, H = m_ws.height;
        int total = (int)m_notes.size();
        float acc = total ? (m_cP * 1.f + m_cG * 0.65f + m_cO * 0.35f) / total * 100.f : 0.f;
        bool win = m_score >= m_oScore;

        auto node = CCNode::create();
        m_result = node;
        node->addChild(CCLayerColor::create({0, 0, 0, 170}));
        auto panel = CCSprite::create("resultat_panneau.png"_spr);
        panel->setPosition({W / 2, H / 2}); fit(panel, W * 0.5f, H * 0.82f);
        node->addChild(panel);

        auto title = CCLabelBMFont::create(win ? "VICTOIRE !" : "DEFAITE", "goldFont.fnt");
        title->setScale(0.9f); title->setPosition({W / 2, H * 0.84f});
        node->addChild(title);
        auto txt = CCString::createWithFormat(
            "Toi : %d   -   Ordinateur : %d\nParfait %d  Bien %d  OK %d  Raté %d\nCombo max %d   Précision %.1f%%%s",
            m_score, m_oScore, m_cP, m_cG, m_cO, m_cM, m_maxCombo, acc,
            m_usedFallback ? "\n(mode tempo BPM)" : "");
        auto info = CCLabelBMFont::create(txt->getCString(), "bigFont.fnt");
        info->setScale(0.42f);
        info->setPosition({W / 2, H * 0.55f});
        node->addChild(info);

        auto menu = CCMenu::create();
        auto rejouerSpr = CCSprite::create("resultat_bouton_rejouer.png"_spr);
        fit(rejouerSpr, W * 0.22f, H * 0.14f);
        auto rejouer = CCMenuItemSpriteExtra::create(rejouerSpr, this, menu_selector(GameLayer::onRetry));
        auto quitterSpr = CCSprite::create("resultat_bouton_quitter.png"_spr);
        fit(quitterSpr, W * 0.22f, H * 0.14f);
        auto quitter = CCMenuItemSpriteExtra::create(quitterSpr, this, menu_selector(GameLayer::onQuit));
        rejouer->setPosition({-W * 0.13f, 0.f});
        quitter->setPosition({W * 0.13f, 0.f});
        menu->addChild(rejouer);
        menu->addChild(quitter);
        menu->setPosition({W / 2, H * 0.3f});
        node->addChild(menu);
        this->addChild(node, 20);
    }

    void onRetry(CCObject*) { startRun(); }
    void onQuit(CCObject*) { quit(); }
};

}  // namespace mg
