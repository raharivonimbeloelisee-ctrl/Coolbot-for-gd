#pragma once
// Jeu de rythme : salon (lobby) + partie à 4 colonnes contre un adversaire ordinateur.
#include <Geode/Geode.hpp>
#include <Geode/fmod/fmod.hpp>

#include <atomic>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <filesystem>
#include <memory>
#include <thread>

#include "Analyzer.hpp"

using namespace geode::prelude;

namespace mg {

// ---------- petits utilitaires de dessin ----------

inline ccColor4F c4(float r, float g, float b, float a = 1.f) { return ccc4f(r, g, b, a); }

inline ccColor4F laneColor(int lane, float a = 1.f) {
    static const float C[4][3] = {{0.75f, 0.35f, 1.0f}, {0.25f, 0.75f, 1.0f}, {0.35f, 0.95f, 0.45f}, {1.0f, 0.45f, 0.40f}};
    return c4(C[lane][0], C[lane][1], C[lane][2], a);
}

// Flèche (0 gauche, 1 bas, 2 haut, 3 droite) faite de deux formes convexes.
inline void drawArrow(CCDrawNode* d, float cx, float cy, float s, int lane, ccColor4F fill, ccColor4F border, float bw) {
    static const float ANG[4] = {180.f, 270.f, 90.f, 0.f};
    float a = ANG[lane] * 3.14159265f / 180.f, ca = std::cos(a), sa = std::sin(a);
    auto P = [&](float x, float y) { return CCPoint{cx + (x * ca - y * sa) * s, cy + (x * sa + y * ca) * s}; };
    CCPoint head[3] = {P(1.f, 0.f), P(0.05f, 0.9f), P(0.05f, -0.9f)};
    CCPoint shaft[4] = {P(0.05f, 0.38f), P(-0.9f, 0.38f), P(-0.9f, -0.38f), P(0.05f, -0.38f)};
    d->drawPolygon(head, 3, fill, bw, border);
    d->drawPolygon(shaft, 4, fill, bw, border);
}

// Image du bouton "THE GAME" (dessinée en code, aucune texture nécessaire).
inline CCSprite* makeGameButtonSprite(CCSize size) {
    auto spr = CCSprite::create();
    spr->setContentSize(size);
    auto d = CCDrawNode::create();
    float w = size.width, h = size.height;
    CCPoint sq[4] = {{4, 4}, {w - 4, 4}, {w - 4, h - 4}, {4, h - 4}};
    d->drawPolygon(sq, 4, c4(0.15f, 0.65f, 0.25f), 2.f, c4(1, 1, 1));
    drawArrow(d, w * 0.5f, h * 0.62f, h * 0.17f, 2, c4(1, 1, 1), c4(0.1f, 0.3f, 0.1f), 0.5f);
    spr->addChild(d);
    auto l = CCLabelBMFont::create("THE GAME", "bigFont.fnt");
    l->limitLabelWidth(w - 12.f, 0.5f, 0.1f);
    l->setPosition({w * 0.5f, h * 0.22f});
    spr->addChild(l);
    return spr;
}

inline void say(char const* text, bool error = true) {
    Notification::create(text, error ? NotificationIcon::Error : NotificationIcon::Success, 2.f)->show();
}

// ---------- décodage + analyse (thread de fond) ----------

struct Job {
    std::atomic<int> state{0};  // 0 en cours, 1 terminé, 2 échec
    std::vector<rb::Note> notes;
};

inline bool decodeMono(FMOD::System* sys, std::string const& path, std::vector<float>& mono, int& rate) {
    FMOD::Sound* snd = nullptr;
    if (sys->createSound(path.c_str(), FMOD_OPENONLY, nullptr, &snd) != FMOD_OK || !snd) return false;
    FMOD_SOUND_TYPE ty;
    FMOD_SOUND_FORMAT fmt;
    int ch = 0, bits = 0;
    snd->getFormat(&ty, &fmt, &ch, &bits);
    float fr = 44100.f;
    int pr = 0;
    snd->getDefaults(&fr, &pr);
    rate = (int)fr;
    bool ok = (fmt == FMOD_SOUND_FORMAT_PCM16 || fmt == FMOD_SOUND_FORMAT_PCMFLOAT) && ch > 0 && rate > 8000;
    if (ok) {
        size_t bps = fmt == FMOD_SOUND_FORMAT_PCM16 ? 2 : 4;
        size_t maxFrames = (size_t)rate * 300;  // 5 minutes maximum
        std::vector<char> buf(65536);
        while (mono.size() < maxFrames) {
            unsigned rd = 0;
            auto r = snd->readData(buf.data(), (unsigned)buf.size(), &rd);
            if (rd == 0 || (r != FMOD_OK && r != FMOD_ERR_FILE_EOF)) break;
            size_t frames = rd / (bps * ch);
            for (size_t i = 0; i < frames; ++i) {
                float sum = 0.f;
                for (int c = 0; c < ch; ++c) {
                    if (fmt == FMOD_SOUND_FORMAT_PCM16) {
                        int16_t v;
                        std::memcpy(&v, buf.data() + (i * ch + c) * 2, 2);
                        sum += v / 32768.f;
                    } else {
                        float v;
                        std::memcpy(&v, buf.data() + (i * ch + c) * 4, 4);
                        sum += v;
                    }
                }
                mono.push_back(sum / ch);
            }
            if (r == FMOD_ERR_FILE_EOF) break;
        }
    }
    snd->release();
    return ok && mono.size() > 4096;
}

// ---------- jeu ----------

struct Chart {
    float t;
    int lane;
    int st = 0;         // joueur : 0 en attente, 1 touchée, 2 ratée
    bool oppHit = false;
    bool oppDone = false;
};

class GameLayer : public CCLayer {
public:
    int m_songId = 0;
    std::string m_path;
    int m_diff = 1;
    int m_oppFrame = 1, m_oppC1 = 0, m_oppC2 = 3;

    std::shared_ptr<Job> m_job;
    int m_phase = 0;  // 0 chargement, 1 jeu, 2 résultats
    std::vector<Chart> m_notes;
    size_t m_head = 0;
    float m_t = -3.f, m_dur = 0.f, m_endT = 0.f;
    bool m_started = false, m_usedFallback = false;
    FMOD::Sound* m_sound = nullptr;
    FMOD::Channel* m_chan = nullptr;
    unsigned m_lenMs = 0;

    int m_score = 0, m_combo = 0, m_maxCombo = 0, m_cP = 0, m_cG = 0, m_cO = 0, m_cM = 0;
    int m_oScore = 0, m_oCombo = 0;
    float m_flash[4] = {0, 0, 0, 0};
    float m_judgeT = 0.f;

    CCDrawNode* m_draw = nullptr;
    CCLabelBMFont *m_info = nullptr, *m_sL = nullptr, *m_cL = nullptr, *m_oL = nullptr, *m_jL = nullptr, *m_cd = nullptr;
    CCNode* m_result = nullptr;
    CCSize m_ws;

    static constexpr float TRAVEL = 1.3f, RECY = 55.f;

    static CCScene* scene(int songId, std::string path, int diff, int of, int oc1, int oc2) {
        auto l = new GameLayer();
        l->m_songId = songId; l->m_path = std::move(path); l->m_diff = diff;
        l->m_oppFrame = of; l->m_oppC1 = oc1; l->m_oppC2 = oc2;
        if (l->init()) l->autorelease(); else { delete l; return nullptr; }
        auto s = CCScene::create();
        s->addChild(l);
        return s;
    }

    float fieldX(bool player) { return m_ws.width * (player ? 0.25f : 0.75f); }
    float laneX(bool player, int lane) { return fieldX(player) + (lane - 1.5f) * 44.f; }

    bool init() override {
        if (!CCLayer::init()) return false;
        m_ws = CCDirector::sharedDirector()->getWinSize();
        auto bg = CCLayerColor::create({14, 14, 28, 255});
        this->addChild(bg, -2);
        m_draw = CCDrawNode::create();
        this->addChild(m_draw, 1);

        m_info = CCLabelBMFont::create("Analyse de la musique...", "bigFont.fnt");
        m_info->setScale(0.6f);
        m_info->setPosition({m_ws.width / 2, m_ws.height / 2});
        this->addChild(m_info, 5);

        m_sL = CCLabelBMFont::create("0", "bigFont.fnt");
        m_sL->setScale(0.5f); m_sL->setPosition({fieldX(true), m_ws.height - 18.f});
        this->addChild(m_sL, 5);
        m_oL = CCLabelBMFont::create("0", "bigFont.fnt");
        m_oL->setScale(0.5f); m_oL->setPosition({fieldX(false), m_ws.height - 18.f});
        this->addChild(m_oL, 5);
        m_cL = CCLabelBMFont::create("", "goldFont.fnt");
        m_cL->setScale(0.7f); m_cL->setPosition({fieldX(true), RECY - 30.f + 8.f});
        this->addChild(m_cL, 5);
        m_jL = CCLabelBMFont::create("", "bigFont.fnt");
        m_jL->setScale(0.6f); m_jL->setPosition({fieldX(true), m_ws.height * 0.55f});
        m_jL->setOpacity(0);
        this->addChild(m_jL, 6);
        m_cd = CCLabelBMFont::create("", "bigFont.fnt");
        m_cd->setScale(1.4f); m_cd->setPosition({m_ws.width / 2, m_ws.height / 2});
        this->addChild(m_cd, 6);

        // icônes des deux joueurs en haut
        auto gm = GameManager::sharedState();
        auto me = SimplePlayer::create(1);
        me->updatePlayerFrame(gm->getPlayerFrame(), gm->m_playerIconType);
        me->setColors(gm->colorForIdx(gm->getPlayerColor()), gm->colorForIdx(gm->getPlayerColor2()));
        if (gm->getPlayerGlow()) me->setGlowOutline(gm->colorForIdx(gm->getPlayerGlowColor()));
        me->setScale(0.6f); me->setPosition({fieldX(true) - 60.f, m_ws.height - 18.f});
        this->addChild(me, 5);
        auto op = SimplePlayer::create(m_oppFrame);
        op->setColors(gm->colorForIdx(m_oppC1), gm->colorForIdx(m_oppC2));
        op->setScale(0.6f); op->setPosition({fieldX(false) - 60.f, m_ws.height - 18.f});
        this->addChild(op, 5);

        FMODAudioEngine::sharedEngine()->pauseAllMusic(true);

        // décodage + analyse en arrière-plan
        m_job = std::make_shared<Job>();
        auto job = m_job;
        auto sys = FMODAudioEngine::sharedEngine()->m_system;
        std::string path = m_path;
        float sens = (float)Mod::get()->getSettingValue<double>("sensitivity");
        std::thread([job, sys, path, sens]() {
            std::vector<float> mono;
            int rate = 44100;
            bool ok = false;
            try {
                if (decodeMono(sys, path, mono, rate)) {
                    rb::Params p;
                    p.sensitivity = sens;
                    job->notes = rb::analyze(mono, rate, p);
                    ok = job->notes.size() >= 10;
                }
            } catch (...) {}
            job->state = ok ? 1 : 2;
        }).detach();

        this->setTouchEnabled(true);
        this->setKeypadEnabled(true);
        this->scheduleUpdate();
        return true;
    }

    void keyBackClicked() override { quit(); }

    void quit() {
        stopMusic();
        FMODAudioEngine::sharedEngine()->resumeAllMusic();
        CCDirector::sharedDirector()->popScene();
    }

    void stopMusic() {
        if (m_chan) { m_chan->stop(); m_chan = nullptr; }
    }

    void onExit() override {
        stopMusic();
        if (m_sound) { m_sound->release(); m_sound = nullptr; }
        CCLayer::onExit();
    }

    // Prépare la partie quand l'analyse est finie.
    void prepare() {
        auto sys = FMODAudioEngine::sharedEngine()->m_system;
        if (!m_sound) {
            if (sys->createStream(m_path.c_str(), FMOD_DEFAULT, nullptr, &m_sound) != FMOD_OK || !m_sound) {
                say("Impossible de lire la musique.");
                quit();
                return;
            }
            m_sound->getLength(&m_lenMs, FMOD_TIMEUNIT_MS);
        }
        std::vector<rb::Note> src;
        if (m_job && m_job->state == 1) src = m_job->notes;
        else {
            m_usedFallback = true;
            src = rb::fromBpm((float)Mod::get()->getSettingValue<int64_t>("fallback_bpm"), m_lenMs / 1000.f, 0.5f);
            say("Analyse impossible : mode tempo (BPM).");
        }
        std::srand((unsigned)std::time(nullptr));
        static const float ACC[3] = {0.60f, 0.80f, 0.95f};
        m_notes.clear();
        for (auto& n : src) {
            Chart c;
            c.t = n.t; c.lane = n.lane;
            c.oppHit = (std::rand() % 1000) / 1000.f < ACC[std::clamp(m_diff, 0, 2)];
            m_notes.push_back(c);
        }
        m_endT = m_notes.empty() ? 5.f : m_notes.back().t + 2.5f;
        startRun();
    }

    void startRun() {
        stopMusic();
        for (auto& n : m_notes) { n.st = 0; n.oppDone = false; }
        m_head = 0; m_t = -3.f; m_started = false;
        m_score = m_combo = m_maxCombo = m_cP = m_cG = m_cO = m_cM = 0;
        m_oScore = m_oCombo = 0;
        if (m_result) { m_result->removeFromParent(); m_result = nullptr; }
        auto sys = FMODAudioEngine::sharedEngine()->m_system;
        sys->playSound(m_sound, nullptr, true, &m_chan);
        m_info->setString("");
        m_phase = 1;
    }

    float disp() { return m_t - (float)Mod::get()->getSettingValue<int64_t>("audio_offset") / 1000.f; }

    void judge(char const* txt, ccColor3B col) {
        m_jL->setString(txt);
        m_jL->setColor(col);
        m_jL->setOpacity(255);
        m_judgeT = 0.5f;
    }

    void hitLane(int lane) {
        m_flash[lane] = 0.15f;
        float d = disp();
        int best = -1;
        float bestAbs = 0.13f;
        for (size_t j = m_head; j < m_notes.size() && m_notes[j].t < d + 0.2f; ++j) {
            auto& n = m_notes[j];
            if (n.st != 0 || n.lane != lane) continue;
            float a = std::fabs(n.t - d);
            if (a < bestAbs) { bestAbs = a; best = (int)j; }
        }
        if (best < 0) return;  // appui dans le vide : pas de pénalité
        m_notes[best].st = 1;
        if (bestAbs <= 0.045f) { m_score += 350; ++m_cP; judge("PARFAIT", {120, 255, 255}); }
        else if (bestAbs <= 0.09f) { m_score += 200; ++m_cG; judge("BIEN", {120, 255, 120}); }
        else { m_score += 100; ++m_cO; judge("OK", {255, 220, 100}); }
        ++m_combo;
        m_maxCombo = std::max(m_maxCombo, m_combo);
    }

    void ccTouchesBegan(CCSet* touches, CCEvent*) override {
        if (m_phase != 1 || m_t < -0.5f) return;
        for (auto it = touches->begin(); it != touches->end(); ++it) {
            auto t = static_cast<CCTouch*>(*it);
            auto p = CCDirector::sharedDirector()->convertToGL(t->getLocationInView());
            if (p.x > m_ws.width * 0.5f) continue;  // moitié gauche = joueur
            float x0 = laneX(true, 0) - 22.f;
            int lane = (int)std::floor((p.x - x0) / 44.f);
            lane = std::clamp(lane, 0, 3);
            hitLane(lane);
        }
    }

    void update(float dt) override {
        if (m_phase == 0) {
            if (m_job && m_job->state != 0) prepare();
            return;
        }
        if (m_phase != 1) return;

        m_t += dt;
        if (!m_started && m_t >= 0.f) {
            m_started = true;
            if (m_chan) m_chan->setPaused(false);
        }
        if (m_started && m_chan) {
            unsigned ms = 0;
            if (m_chan->getPosition(&ms, FMOD_TIMEUNIT_MS) == FMOD_OK) {
                float a = ms / 1000.f;
                if (std::fabs(a - m_t) > 0.05f) m_t = a;
                else m_t += (a - m_t) * 0.1f;
            }
        }
        // compte à rebours
        if (m_t < 0.f) {
            int n = (int)std::ceil(-m_t);
            m_cd->setString(std::to_string(n).c_str());
        } else m_cd->setString("");

        float d = disp();
        // ratés du joueur + coups de l'adversaire
        static const int OPP_PTS[3] = {350, 350, 200};
        for (size_t j = m_head; j < m_notes.size() && m_notes[j].t < d + 0.2f; ++j) {
            auto& n = m_notes[j];
            if (n.st == 0 && n.t < d - 0.13f) {
                n.st = 2; ++m_cM; m_combo = 0;
                judge("RATÉ", {255, 90, 90});
            }
            if (!n.oppDone && n.t <= d) {
                n.oppDone = true;
                if (n.oppHit) { m_oScore += OPP_PTS[std::rand() % 3]; ++m_oCombo; }
                else m_oCombo = 0;
            }
        }
        while (m_head < m_notes.size() && m_notes[m_head].st != 0 && m_notes[m_head].oppDone) ++m_head;

        // HUD
        m_sL->setString(std::to_string(m_score).c_str());
        m_oL->setString(std::to_string(m_oScore).c_str());
        m_cL->setString(m_combo >= 2 ? (std::to_string(m_combo) + " combo").c_str() : "");
        if (m_judgeT > 0.f) {
            m_judgeT -= dt;
            if (m_judgeT <= 0.f) m_jL->setOpacity(0);
        }
        for (auto& f : m_flash) f = std::max(0.f, f - dt);

        render(d);

        if (d > m_endT) finish();
    }

    void render(float d) {
        m_draw->clear();
        float speed = (m_ws.height - 60.f - RECY) / TRAVEL;
        ccColor4F dark = c4(0.05f, 0.05f, 0.1f, 0.9f);
        for (int side = 0; side < 2; ++side) {
            bool pl = side == 0;
            float x0 = laneX(pl, 0) - 22.f, x1 = laneX(pl, 3) + 22.f;
            CCPoint bgp[4] = {{x0, 0}, {x1, 0}, {x1, m_ws.height}, {x0, m_ws.height}};
            m_draw->drawPolygon(bgp, 4, c4(0.08f, 0.08f, 0.16f, 0.9f), 0.f, c4(0, 0, 0, 0));
            for (int l = 0; l < 4; ++l) {
                float fl = pl ? m_flash[l] / 0.15f : 0.f;
                drawArrow(m_draw, laneX(pl, l), RECY, 17.f, l, laneColor(l, 0.15f + 0.6f * fl), c4(1, 1, 1, 0.5f), 0.7f);
            }
        }
        for (size_t j = m_head; j < m_notes.size(); ++j) {
            auto& n = m_notes[j];
            float dt = n.t - d;
            if (dt > TRAVEL + 0.1f) break;
            float y = RECY + dt * speed;
            if (n.st == 0) drawArrow(m_draw, laneX(true, n.lane), y, 17.f, n.lane, laneColor(n.lane), c4(1, 1, 1, 0.9f), 0.8f);
            if (!n.oppDone) drawArrow(m_draw, laneX(false, n.lane), y, 17.f, n.lane, laneColor(n.lane, 0.85f), c4(0.2f, 0.2f, 0.3f, 1), 0.8f);
        }
        (void)dark;
    }

    void finish() {
        if (m_phase == 2) return;
        m_phase = 2;
        stopMusic();
        m_draw->clear();
        int total = (int)m_notes.size();
        float acc = total ? (m_cP * 1.f + m_cG * 0.65f + m_cO * 0.35f) / total * 100.f : 0.f;
        bool win = m_score >= m_oScore;

        auto node = CCNode::create();
        m_result = node;
        auto bgl = CCLayerColor::create({0, 0, 0, 200});
        node->addChild(bgl);
        auto title = CCLabelBMFont::create(win ? "VICTOIRE !" : "DEFAITE", "goldFont.fnt");
        title->setScale(1.1f);
        title->setPosition({m_ws.width / 2, m_ws.height - 50.f});
        node->addChild(title);
        auto txt = CCString::createWithFormat(
            "Toi : %d   -   Adversaire : %d\nParfait %d  Bien %d  OK %d  Rate %d\nCombo max %d   Precision %.1f%%%s",
            m_score, m_oScore, m_cP, m_cG, m_cO, m_cM, m_maxCombo, acc, m_usedFallback ? "\n(mode tempo BPM)" : "");
        auto info = CCLabelBMFont::create(txt->getCString(), "bigFont.fnt");
        info->setScale(0.45f);
        info->setPosition({m_ws.width / 2, m_ws.height / 2 + 10.f});
        node->addChild(info);

        auto menu = CCMenu::create();
        auto retry = CCMenuItemSpriteExtra::create(ButtonSprite::create("Rejouer"), this, menu_selector(GameLayer::onRetry));
        auto leave = CCMenuItemSpriteExtra::create(ButtonSprite::create("Quitter"), this, menu_selector(GameLayer::onQuit));
        retry->setPosition({-70.f, -70.f});
        leave->setPosition({70.f, -70.f});
        menu->addChild(retry);
        menu->addChild(leave);
        menu->setPosition({m_ws.width / 2, m_ws.height / 2});
        node->addChild(menu);
        this->addChild(node, 20);
    }

    void onRetry(CCObject*) { startRun(); }
    void onQuit(CCObject*) { quit(); }
};

// ---------- salon ----------

class LobbyLayer : public CCLayer {
public:
    TextInput* m_input = nullptr;
    CCLabelBMFont* m_diffLabel = nullptr;
    int m_diff = 1;
    int m_oppFrame = 1, m_oppC1 = 0, m_oppC2 = 3;
    CCNode* m_oppHolder = nullptr;
    CCSize m_ws;

    static CCScene* scene() {
        auto l = new LobbyLayer();
        if (l->init()) l->autorelease(); else { delete l; return nullptr; }
        auto s = CCScene::create();
        s->addChild(l);
        return s;
    }

    bool init() override {
        if (!CCLayer::init()) return false;
        m_ws = CCDirector::sharedDirector()->getWinSize();
        this->addChild(CCLayerColor::create({20, 20, 45, 255}), -2);
        m_diff = (int)Mod::get()->getSavedValue<int64_t>("diff", 1);

        auto title = CCLabelBMFont::create("THE GAME", "goldFont.fnt");
        title->setPosition({m_ws.width / 2, m_ws.height - 26.f});
        this->addChild(title);

        // joueur (à gauche)
        auto gm = GameManager::sharedState();
        auto me = SimplePlayer::create(1);
        me->updatePlayerFrame(gm->getPlayerFrame(), gm->m_playerIconType);
        me->setColors(gm->colorForIdx(gm->getPlayerColor()), gm->colorForIdx(gm->getPlayerColor2()));
        if (gm->getPlayerGlow()) me->setGlowOutline(gm->colorForIdx(gm->getPlayerGlowColor()));
        me->setScale(1.6f);
        me->setPosition({m_ws.width * 0.2f, m_ws.height * 0.68f});
        this->addChild(me);
        auto meL = CCLabelBMFont::create("TOI", "bigFont.fnt");
        meL->setScale(0.5f); meL->setPosition({m_ws.width * 0.2f, m_ws.height * 0.68f - 42.f});
        this->addChild(meL);

        auto vs = CCLabelBMFont::create("VS", "goldFont.fnt");
        vs->setScale(1.2f); vs->setPosition({m_ws.width / 2, m_ws.height * 0.68f});
        this->addChild(vs);

        // adversaire (à droite)
        m_oppHolder = CCNode::create();
        m_oppHolder->setPosition({m_ws.width * 0.8f, m_ws.height * 0.68f});
        this->addChild(m_oppHolder);
        auto oppL = CCLabelBMFont::create("ORDINATEUR", "bigFont.fnt");
        oppL->setScale(0.45f); oppL->setPosition({m_ws.width * 0.8f, m_ws.height * 0.68f - 42.f});
        this->addChild(oppL);
        randomOpp();

        auto menuOpp = CCMenu::create();
        auto reroll = CCMenuItemSpriteExtra::create(ButtonSprite::create("Autre", "bigFont.fnt", "GJ_button_04.png", 0.5f), this, menu_selector(LobbyLayer::onReroll));
        reroll->setPosition({m_ws.width * 0.8f - m_ws.width / 2, m_ws.height * 0.68f - 70.f - m_ws.height / 2});
        menuOpp->addChild(reroll);
        this->addChild(menuOpp);

        // ID de la musique
        auto idLabel = CCLabelBMFont::create("ID de la musique (bibliothèque GD, déjà téléchargée)", "bigFont.fnt");
        idLabel->setScale(0.35f);
        idLabel->setPosition({m_ws.width / 2, 108.f});
        this->addChild(idLabel);
        m_input = TextInput::create(200.f, "ex : 1234567");
        m_input->setCommonFilter(CommonFilter::Uint);
        m_input->setMaxCharCount(9);
        m_input->setString(std::to_string(Mod::get()->getSavedValue<int64_t>("song_id", 0)));
        m_input->setPosition({m_ws.width / 2, 85.f});
        this->addChild(m_input);

        auto menu = CCMenu::create();
        m_diffLabel = nullptr;
        auto diffBtn = CCMenuItemSpriteExtra::create(ButtonSprite::create(diffName(), "bigFont.fnt", "GJ_button_04.png", 0.6f), this, menu_selector(LobbyLayer::onDiff));
        m_diffItem = diffBtn;
        diffBtn->setPosition({-110.f, -85.f});
        auto play = CCMenuItemSpriteExtra::create(ButtonSprite::create("JOUER"), this, menu_selector(LobbyLayer::onPlay));
        play->setPosition({110.f, -85.f});
        menu->addChild(diffBtn);
        menu->addChild(play);
        menu->setPosition({m_ws.width / 2, m_ws.height / 2});
        this->addChild(menu);

        auto back = CCMenu::create();
        auto bb = CCMenuItemSpriteExtra::create(CCSprite::createWithSpriteFrameName("GJ_arrow_01_001.png"), this, menu_selector(LobbyLayer::onBack));
        back->addChild(bb);
        back->setPosition({25.f, m_ws.height - 25.f});
        this->addChild(back);

        this->setKeypadEnabled(true);
        return true;
    }

    CCMenuItemSpriteExtra* m_diffItem = nullptr;

    char const* diffName() { static const char* N[3] = {"Facile", "Normal", "Difficile"}; return N[std::clamp(m_diff, 0, 2)]; }

    void randomOpp() {
        auto gm = GameManager::sharedState();
        int n = std::max(10, gm->countForType(IconType::Cube));
        m_oppFrame = 1 + std::rand() % n;
        m_oppC1 = std::rand() % 41;
        m_oppC2 = std::rand() % 41;
        m_oppHolder->removeAllChildren();
        auto op = SimplePlayer::create(m_oppFrame);
        op->setColors(gm->colorForIdx(m_oppC1), gm->colorForIdx(m_oppC2));
        op->setScale(1.6f);
        m_oppHolder->addChild(op);
    }

    void onReroll(CCObject*) { randomOpp(); }

    void onDiff(CCObject*) {
        m_diff = (m_diff + 1) % 3;
        Mod::get()->setSavedValue<int64_t>("diff", m_diff);
        // reconstruit l'image du bouton
        m_diffItem->setSprite(ButtonSprite::create(diffName(), "bigFont.fnt", "GJ_button_04.png", 0.6f));
    }

    void onBack(CCObject*) { CCDirector::sharedDirector()->popScene(); }
    void keyBackClicked() override { CCDirector::sharedDirector()->popScene(); }

    void onPlay(CCObject*) {
        std::string s = m_input->getString();
        if (s.empty()) { say("Entre l'ID d'une musique."); return; }
        int id = 0;
        try { id = std::stoi(s); } catch (...) { say("ID invalide."); return; }
        if (id <= 0) { say("ID invalide."); return; }
        Mod::get()->setSavedValue<int64_t>("song_id", id);

        std::string path = MusicDownloadManager::sharedState()->pathForSong(id).c_str();
        std::error_code ec;
        if (path.empty() || !std::filesystem::exists(path, ec)) {
            // musique officielle (numéro de piste)
            std::string off = LevelTools::getAudioFileName(id).c_str();
            auto full = CCFileUtils::sharedFileUtils()->fullPathForFilename(off.c_str(), false);
            if (!full.empty() && std::filesystem::exists(std::string(full), ec)) path = full;
            else path.clear();
        }
        if (path.empty()) {
            say("Musique introuvable : télécharge-la d'abord (bibliothèque de musique).");
            return;
        }
        auto sc = GameLayer::scene(id, path, m_diff, m_oppFrame, m_oppC1, m_oppC2);
        if (sc) CCDirector::sharedDirector()->pushScene(CCTransitionFade::create(0.3f, sc));
    }
};

}  // namespace mg
