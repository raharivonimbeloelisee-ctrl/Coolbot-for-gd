#pragma once
// Analyse de rythme : détecte les attaques (coups de batterie, notes) d'un son
// et les répartit sur 4 colonnes selon la fréquence dominante.
// C++ pur, sans dépendance Geode, pour pouvoir être testé hors du jeu.
#include <algorithm>
#include <array>
#include <cmath>
#include <complex>
#include <cstdint>
#include <functional>
#include <vector>

namespace rb {

struct Note {
    float t;   // temps de l'attaque en secondes
    int lane;  // 0..3
};

struct Params {
    float sensitivity = 1.0f;  // plus grand = plus de notes
    float minGap = 0.14f;      // écart minimal entre deux notes (s)
};

namespace detail {

constexpr int N = 1024;
constexpr int HOP = 512;
constexpr int BANDS = 4;

struct FFT {
    std::vector<std::complex<float>> tw;
    std::vector<int> rev;
    FFT() : tw(N / 2), rev(N) {
        for (int i = 0; i < N / 2; ++i) {
            float a = -2.f * 3.14159265358979f * i / N;
            tw[i] = {std::cos(a), std::sin(a)};
        }
        int bits = 0;
        while ((1 << bits) < N) ++bits;
        for (int i = 0; i < N; ++i) {
            int r = 0;
            for (int b = 0; b < bits; ++b)
                if (i & (1 << b)) r |= 1 << (bits - 1 - b);
            rev[i] = r;
        }
    }
    void run(std::vector<std::complex<float>>& x) const {
        for (int i = 0; i < N; ++i)
            if (i < rev[i]) std::swap(x[i], x[rev[i]]);
        for (int len = 2; len <= N; len <<= 1) {
            int step = N / len;
            for (int i = 0; i < N; i += len) {
                for (int j = 0; j < len / 2; ++j) {
                    auto w = tw[j * step];
                    auto u = x[i + j];
                    auto v = x[i + j + len / 2] * w;
                    x[i + j] = u + v;
                    x[i + j + len / 2] = u - v;
                }
            }
        }
    }
};

}  // namespace detail

// mono : échantillons entre -1 et 1. progress (optionnel) reçoit une valeur 0..1.
inline std::vector<Note> analyze(std::vector<float> const& mono, int sampleRate, Params p = {},
                                 std::function<void(float)> progress = {}) {
    using namespace detail;
    std::vector<Note> notes;
    if (sampleRate <= 0 || (int)mono.size() < N * 4) return notes;

    const int frames = ((int)mono.size() - N) / HOP;
    const float binHz = (float)sampleRate / N;

    // bornes des 4 bandes en indices de bins
    const float edges[BANDS + 1] = {40.f, 250.f, 1000.f, 3500.f, 11000.f};
    int lo[BANDS], hi[BANDS];
    for (int b = 0; b < BANDS; ++b) {
        lo[b] = std::max(1, (int)(edges[b] / binHz));
        hi[b] = std::min(N / 2 - 1, (int)(edges[b + 1] / binHz));
        if (hi[b] < lo[b]) hi[b] = lo[b];
    }

    FFT fft;
    std::vector<float> win(N);
    for (int i = 0; i < N; ++i) win[i] = 0.5f - 0.5f * std::cos(2.f * 3.14159265358979f * i / (N - 1));

    std::vector<std::complex<float>> buf(N);
    std::vector<float> prev(N / 2, 0.f), cur(N / 2, 0.f);
    std::vector<std::array<float, BANDS>> flux(frames);

    for (int f = 0; f < frames; ++f) {
        const float* s = mono.data() + (size_t)f * HOP;
        for (int i = 0; i < N; ++i) buf[i] = {s[i] * win[i], 0.f};
        fft.run(buf);
        for (int k = 1; k < N / 2; ++k) cur[k] = std::log1p(20.f * std::abs(buf[k]) / N * 8.f);
        for (int b = 0; b < BANDS; ++b) {
            float sum = 0.f;
            for (int k = lo[b]; k <= hi[b]; ++k) sum += std::max(0.f, cur[k] - prev[k]);
            sum /= std::sqrt((float)(hi[b] - lo[b] + 1));  // compense la largeur de bande
            flux[f][b] = sum;
        }
        prev.swap(cur);
        if (progress && (f & 255) == 0) progress(0.8f * f / frames);
    }

    // demi-largeur de la fenêtre du seuil adaptatif (~0,35 s)
    const int W = std::max(4, (int)(0.35f * sampleRate / HOP));

    // seuil adaptatif PAR BANDE : moyenne + k * écart-type sur une fenêtre autour de chaque image
    // (un seuil global ferait disparaître les sons aigus et faibles, comme les hi-hats)
    const float k = 1.25f / std::max(0.2f, p.sensitivity);
    std::vector<std::vector<float>> thr(BANDS, std::vector<float>(frames));
    float globalMean[BANDS] = {};
    for (int b = 0; b < BANDS; ++b) {
        std::vector<double> c1(frames + 1, 0.0), c2(frames + 1, 0.0);
        for (int f = 0; f < frames; ++f) {
            float v = flux[f][b];
            c1[f + 1] = c1[f] + v;
            c2[f + 1] = c2[f] + (double)v * v;
        }
        globalMean[b] = (float)(c1[frames] / frames);
        for (int f = 0; f < frames; ++f) {
            int a = std::max(0, f - W), e = std::min(frames, f + W + 1);
            double n = e - a, m = (c1[e] - c1[a]) / n;
            double var = std::max(0.0, (c2[e] - c2[a]) / n - m * m);
            thr[b][f] = (float)(m + k * std::sqrt(var));
        }
    }

    // pics de chaque bande, puis fusion (on garde le plus fort dans une fenêtre minGap)
    struct Peak { int f; int band; float v; };
    std::vector<Peak> cand;
    for (int b = 0; b < BANDS; ++b) {
        const float floorV = std::max(0.02f, 0.25f * globalMean[b]);
        for (int f = 2; f < frames - 2; ++f) {
            float v = flux[f][b];
            if (v <= thr[b][f] || v < floorV) continue;
            bool isMax = true;
            for (int d = -2; d <= 2 && isMax; ++d)
                if (d != 0 && flux[f + d][b] > v) isMax = false;
            if (isMax) cand.push_back({f, b, v / thr[b][f]});
        }
    }
    std::sort(cand.begin(), cand.end(), [](Peak const& a, Peak const& b) { return a.f < b.f; });
    const int gapFrames = std::max(1, (int)(p.minGap * sampleRate / HOP));
    std::vector<Peak> peaks;
    for (auto const& c : cand) {
        if (!peaks.empty() && c.f - peaks.back().f < gapFrames) {
            if (c.v > peaks.back().v) peaks.back() = c;
        } else {
            peaks.push_back(c);
        }
    }

    // attribution des colonnes : bande dominante, sans répéter 4 fois la même colonne
    int last = -1, run = 0;
    for (auto const& pk : peaks) {
        int lane = pk.band;
        if (lane == last && run >= 2) {
            float best = -1.f;
            for (int b = 0; b < BANDS; ++b) {
                if (b == lane) continue;
                float sc = flux[pk.f][b] / std::max(thr[b][pk.f], 1e-4f);
                if (sc > best) { best = sc; lane = b; }
            }
        }
        run = (lane == last) ? run + 1 : 1;
        last = lane;
        // le flux compare l'image f à f-1 : l'attaque est située vers le début de l'image f
        float t = ((float)pk.f * HOP + N * 0.25f) / sampleRate;
        notes.push_back({t, lane});
    }
    if (progress) progress(1.f);
    return notes;
}

// Repli : notes régulières à partir d'un tempo (BPM), sur toute la durée.
inline std::vector<Note> fromBpm(float bpm, float durationSec, float firstBeat = 0.f) {
    std::vector<Note> out;
    if (bpm < 40.f) bpm = 40.f;
    float step = 60.f / bpm;
    int i = 0;
    for (float t = firstBeat; t < durationSec; t += step, ++i) out.push_back({t, (i * 7 + i / 3) % 4});
    return out;
}

}  // namespace rb
