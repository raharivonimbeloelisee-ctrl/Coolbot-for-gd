#pragma once
// Salon défilant : on marche avec les flèches à l'écran, on entre dans une porte pour lancer une partie.
#include <Geode/Geode.hpp>
#include <vector>
#include "Game.hpp"

using namespace geode::prelude;

namespace mg {

class LobbyLayer : public CCLayer {
public:
    CCSize m_ws;
    float m_WW = 0.f, m_floorH = 0.f;
    CCNode* m_world = nullptr;
    CCSprite* m_me = nullptr;
    CCSprite* m_bot = nullptr;
    float m_px = 0.f, m_vx = 0.f, m_camX = 0.f, m_bx = 0.f, m_bdir = 1.f;
    bool m_padL = false, m_padR = false;
    CCSprite *m_padLb = nullptr, *m_padLbP = nullptr, *m_padRb = nullptr, *m_padRbP = nullptr;
    CCRect m_leftRect, m_rightRect;
    CCMenuItem* m_enter = nullptr;
    CCMenu* m_enterMenu = nullptr;
    CCNode* m_panel = nullptr;
    TextInput* m_input = nullptr;
    CCLabelBMFont* m_diffLabel = nullptr;
    int m_diff = 1;
    int m_hotDoor = -1;
    std::vector<float> m_doorX;
    std::vector<CCLabelBMFont*> m_doorLabels;
    float m_toastT = 0.f;
    CCLabelBMFont* m_toast = nullptr;
    CCNode* m_menuTop = nullptr;
    bool m_loggedUpdate = false;

    static CCScene* scene() {
        auto l = new LobbyLayer();
        if (l->init()) l->autorelease(); else { delete l; return nullptr; }
        auto s = CCScene::create();
        s->addChild(l);
        return s;
    }

    void say2(char const* msg) {
        m_toast->setString(msg);
        m_toast->setOpacity(255);
        m_toastT = 1.6f;
    }

    bool init() override {
        if (!CCLayer::init()) return false;
        m_ws = CCDirector::sharedDirector()->getWinSize();
        float W = m_ws.width, H = m_ws.height;
        m_WW = W * 2.2f;
        m_floorH = H * 0.14f;
        m_diff = (int)Mod::get()->getSavedValue<int64_t>("diff", 1);

        auto bg = CCSprite::create("salon_fond.png"_spr);
        bg->setPosition({W / 2, H / 2}); fit(bg, W, H);
        this->addChild(bg, -3);

        m_world = CCNode::create();
        this->addChild(m_world, 0);

        // sol en tuiles
        int tiles = (int)(m_WW / m_floorH) + 2;
        for (int i = 0; i < tiles; ++i) {
            auto t = CCSprite::create("salon_sol.png"_spr);
            t->setAnchorPoint({0.f, 0.f});
            t->setPosition({i * m_floorH, 0.f}); fit(t, m_floorH, m_floorH);
            m_world->addChild(t, 1);
        }
        // piliers
        for (int i = 0; i < 6; ++i) {
            auto p = CCSprite::create("salon_pilier.png"_spr);
            p->setAnchorPoint({0.5f, 0.f});
            p->setPosition({m_WW * (0.12f + i * 0.16f), m_floorH}); fit(p, H * 0.09f, H * 0.42f);
            m_world->addChild(p, 1);
        }
        // portes : Partie, Créer, Rejoindre
        static const char* NAMES[3] = {"Partie", "Créer", "Rejoindre"};
        float doors[3] = {m_WW * 0.2f, m_WW * 0.5f, m_WW * 0.8f};
        for (int i = 0; i < 3; ++i) {
            auto d = CCSprite::create("salon_porte.png"_spr);
            d->setAnchorPoint({0.5f, 0.f});
            d->setPosition({doors[i], m_floorH}); fit(d, W * 0.2f, H * 0.36f);
            m_world->addChild(d, 2);
            m_doorX.push_back(doors[i]);
            auto l = CCLabelBMFont::create(NAMES[i], "bigFont.fnt");
            l->setScale(0.45f);
            l->setPosition({doors[i], m_floorH + H * 0.36f + 14.f});
            m_world->addChild(l, 3);
            m_doorLabels.push_back(l);
        }

        // joueur et ordinateur
        m_px = 80.f;
        m_me = CCSprite::create("salon_joueur.png"_spr);
        m_me->setAnchorPoint({0.5f, 0.f}); fit(m_me, H * 0.12f, H * 0.12f);
        m_world->addChild(m_me, 4);
        m_bx = m_WW * 0.6f;
        m_bot = CCSprite::create("salon_ordinateur.png"_spr);
        m_bot->setAnchorPoint({0.5f, 0.f}); fit(m_bot, H * 0.12f, H * 0.12f);
        m_world->addChild(m_bot, 4);
        auto botLbl = CCLabelBMFont::create("Ordinateur", "bigFont.fnt");
        botLbl->setScale(0.35f); botLbl->setPosition({m_WW * 0.6f, m_floorH + H * 0.14f + 8.f});
        m_world->addChild(botLbl, 5);

        // panneau du haut (écran fixe)
        auto top = CCSprite::create("salon_panneau_haut.png"_spr);
        top->setPosition({W / 2, H - H * 0.075f - 8.f}); fit(top, W * 0.92f, H * 0.15f);
        this->addChild(top, 5);
        m_menuTop = CCMenu::create();
        auto mk = [&](char const* label, float x, SEL_MenuHandler sel, char const* bg) {
            auto spr = CCSprite::create(bg);
            fit(spr, H * 0.11f, H * 0.11f);
            auto item = CCMenuItemSpriteExtra::create(spr, this, sel);
            auto lbl = CCLabelBMFont::create(label, "bigFont.fnt");
            lbl->setScale(0.28f);
            lbl->setPosition({spr->getContentSize().width * 0.5f, -6.f});
            item->addChild(lbl);
            item->setPosition({x, 0.f});
            m_menuTop->addChild(item);
        };
        mk("Profil", -W * 0.36f, menu_selector(LobbyLayer::onProfil), "salon_bouton_case.png"_spr);
        mk("Musique", -W * 0.27f, menu_selector(LobbyLayer::onMusique), "salon_bouton_case.png"_spr);
        mk("Infos", W * 0.27f, menu_selector(LobbyLayer::onInfos), "salon_bouton_case.png"_spr);
        auto partie = CCSprite::create("salon_bouton_partie.png"_spr);
        fit(partie, W * 0.2f, H * 0.11f);
        auto partieItem = CCMenuItemSpriteExtra::create(partie, this, menu_selector(LobbyLayer::onPartie));
        partieItem->setPosition({0.f, 0.f});
        auto pl = CCLabelBMFont::create("PARTIE", "bigFont.fnt");
        pl->setScale(0.4f); pl->setPosition({partie->getContentSize().width * 0.5f, partie->getContentSize().height * 0.5f});
        partieItem->addChild(pl);
        m_menuTop->addChild(partieItem);
        m_menuTop->setPosition({W / 2, H - H * 0.075f - 8.f});
        this->addChild(m_menuTop, 6);

        // flèches à l'écran, en bas à gauche
        float pad = H * 0.2f;
        m_leftRect = CCRect(8.f, 8.f, pad, pad);
        m_rightRect = CCRect(pad + 16.f, 8.f, pad, pad);
        m_padLb = CCSprite::create("salon_pave_fleche.png"_spr);
        m_padLb->setAnchorPoint({0.f, 0.f}); m_padLb->setPosition({8.f, 8.f}); fit(m_padLb, pad, pad);
        m_padLbP = CCSprite::create("salon_pave_fleche_pressee.png"_spr);
        m_padLbP->setAnchorPoint({0.f, 0.f}); m_padLbP->setPosition({8.f, 8.f}); fit(m_padLbP, pad, pad);
        m_padLbP->setVisible(false);
        auto il = CCSprite::create("salon_fleche_gauche.png"_spr);
        il->setPosition({8.f + pad / 2, 8.f + pad / 2}); fit(il, pad * 0.5f, pad * 0.5f);
        m_padRb = CCSprite::create("salon_pave_fleche.png"_spr);
        m_padRb->setAnchorPoint({0.f, 0.f}); m_padRb->setPosition({pad + 16.f, 8.f}); fit(m_padRb, pad, pad);
        m_padRbP = CCSprite::create("salon_pave_fleche_pressee.png"_spr);
        m_padRbP->setAnchorPoint({0.f, 0.f}); m_padRbP->setPosition({pad + 16.f, 8.f}); fit(m_padRbP, pad, pad);
        m_padRbP->setVisible(false);
        auto ir = CCSprite::create("salon_fleche_droite.png"_spr);
        ir->setPosition({pad + 16.f + pad / 2, 8.f + pad / 2}); fit(ir, pad * 0.5f, pad * 0.5f);
        this->addChild(m_padLb, 7); this->addChild(m_padLbP, 7); this->addChild(il, 8);
        this->addChild(m_padRb, 7); this->addChild(m_padRbP, 7); this->addChild(ir, 8);

        // bouton ENTRER (apparaît quand on est devant une porte)
        auto es = CCSprite::create("salon_bouton_partie.png"_spr);
        fit(es, W * 0.2f, H * 0.11f);
        auto enterItem = CCMenuItemSpriteExtra::create(es, this, menu_selector(LobbyLayer::onEnterDoor));
        auto el = CCLabelBMFont::create("ENTRER", "bigFont.fnt");
        el->setScale(0.4f); el->setPosition({es->getContentSize().width * 0.5f, es->getContentSize().height * 0.5f});
        enterItem->addChild(el);
        m_enterMenu = CCMenu::create();
        m_enterMenu->addChild(enterItem);
        m_enterMenu->setPosition({W - W * 0.13f, H * 0.12f});
        m_enterMenu->setVisible(false);
        this->addChild(m_enterMenu, 7);
        m_enter = enterItem;

        // toast
        m_toast = CCLabelBMFont::create("", "goldFont.fnt");
        m_toast->setScale(0.45f); m_toast->setPosition({W / 2, H * 0.6f}); m_toast->setOpacity(0);
        this->addChild(m_toast, 9);

        this->setTouchEnabled(true);
        this->setKeypadEnabled(true);
        this->scheduleUpdate();
        return true;
    }

    void keyBackClicked() override {
        if (m_panel) { closePanel(); return; }
        CCDirector::sharedDirector()->popScene();
    }

    // ----- entrées tactiles -----
    void ccTouchesBegan(CCSet* touches, CCEvent*) override {
        if (m_panel) return;
        for (auto it = touches->begin(); it != touches->end(); ++it) {
            auto t = static_cast<CCTouch*>(*it);
            auto p = CCDirector::sharedDirector()->convertToGL(t->getLocationInView());
            if (m_leftRect.containsPoint(p)) m_padL = true;
            if (m_rightRect.containsPoint(p)) m_padR = true;
        }
    }
    void ccTouchesEnded(CCSet*, CCEvent*) override { m_padL = m_padR = false; }

    void onEnterDoor(CCObject*) {
        if (m_hotDoor == 0) onPartie(nullptr);
        else if (m_hotDoor == 1) say2("Partie LAN : pas encore incluse");
        else if (m_hotDoor == 2) say2("Rejoindre : pas encore inclus");
    }

    void onProfil(CCObject*) { say2("Profil : bientôt"); }
    void onMusique(CCObject*) { say2("Musique : bientôt"); }
    void onInfos(CCObject*) { say2("Marche, entre dans une porte, choisis une musique"); }

    // ----- panneau de configuration de partie -----
    void onPartie(CCObject*) {
        if (m_panel) return;
        float W = m_ws.width, H = m_ws.height;
        m_panel = CCNode::create();
        this->addChild(m_panel, 20);
        auto dim = CCLayerColor::create({0, 0, 0, 170});
        m_panel->addChild(dim);
        auto box = CCSprite::create("resultat_panneau.png"_spr);
        box->setPosition({W / 2, H / 2}); fit(box, W * 0.5f, H * 0.8f);
        m_panel->addChild(box);

        auto title = CCLabelBMFont::create("PARTIE CONTRE L'ORDINATEUR", "goldFont.fnt");
        title->setScale(0.5f); title->setPosition({W / 2, H * 0.84f});
        m_panel->addChild(title);

        auto idLbl = CCLabelBMFont::create("ID de la musique (téléchargée)", "bigFont.fnt");
        idLbl->setScale(0.32f); idLbl->setPosition({W / 2, H * 0.7f});
        m_panel->addChild(idLbl);
        m_input = TextInput::create(W * 0.3f, "ex : 1234567", "bigFont.fnt");
        m_input->setCommonFilter(CommonFilter::Uint);
        m_input->setMaxCharCount(9);
        m_input->setString(std::to_string(Mod::get()->getSavedValue<int64_t>("song_id", 0)));
        m_input->setPosition({W / 2, H * 0.6f});
        m_panel->addChild(m_input);

        auto menu = CCMenu::create();
        auto dSpr = CCSprite::create("salon_bouton_case.png"_spr);
        fit(dSpr, W * 0.2f, H * 0.13f);
        auto dItem = CCMenuItemSpriteExtra::create(dSpr, this, menu_selector(LobbyLayer::onDiff));
        m_diffLabel = CCLabelBMFont::create(diffName(), "bigFont.fnt");
        m_diffLabel->setScale(0.4f);
        m_diffLabel->setPosition({dSpr->getContentSize().width * 0.5f, dSpr->getContentSize().height * 0.5f});
        dItem->addChild(m_diffLabel);
        dItem->setPosition({-W * 0.13f, -H * 0.12f});
        menu->addChild(dItem);

        auto jSpr = CCSprite::create("resultat_bouton_rejouer.png"_spr);
        fit(jSpr, W * 0.2f, H * 0.13f);
        auto jItem = CCMenuItemSpriteExtra::create(jSpr, this, menu_selector(LobbyLayer::onPlay));
        auto jl = CCLabelBMFont::create("JOUER", "bigFont.fnt");
        jl->setScale(0.4f); jl->setPosition({jSpr->getContentSize().width * 0.5f, jSpr->getContentSize().height * 0.5f});
        jItem->addChild(jl);
        jItem->setPosition({0.f, -H * 0.12f});
        menu->addChild(jItem);

        auto cSpr = CCSprite::create("resultat_bouton_quitter.png"_spr);
        fit(cSpr, W * 0.2f, H * 0.13f);
        auto cItem = CCMenuItemSpriteExtra::create(cSpr, this, menu_selector(LobbyLayer::onClose));
        auto cl = CCLabelBMFont::create("FERMER", "bigFont.fnt");
        cl->setScale(0.4f); cl->setPosition({cSpr->getContentSize().width * 0.5f, cSpr->getContentSize().height * 0.5f});
        cItem->addChild(cl);
        cItem->setPosition({W * 0.13f, -H * 0.12f});
        menu->addChild(cItem);
        menu->setPosition({W / 2, 0.f});
        m_panel->addChild(menu);
    }

    void closePanel() {
        if (m_panel) { m_panel->removeFromParent(); m_panel = nullptr; m_input = nullptr; m_diffLabel = nullptr; }
    }

    void onClose(CCObject*) { closePanel(); }

    char const* diffName() {
        static const char* N[3] = {"Facile", "Normal", "Difficile"};
        return N[std::clamp(m_diff, 0, 2)];
    }

    void onDiff(CCObject*) {
        m_diff = (m_diff + 1) % 3;
        Mod::get()->setSavedValue<int64_t>("diff", m_diff);
        if (m_diffLabel) m_diffLabel->setString(diffName());
    }

    void onPlay(CCObject*) {
        if (!m_input) return;
        std::string s = m_input->getString();
        int id = 0;
        try { id = std::stoi(s); } catch (...) { say("ID invalide."); return; }
        if (id <= 0) { say("ID invalide."); return; }
        Mod::get()->setSavedValue<int64_t>("song_id", id);

        std::string path = MusicDownloadManager::sharedState()->pathForSong(id).c_str();
        std::error_code ec;
        if (path.empty() || !std::filesystem::exists(path, ec)) {
            std::string off = LevelTools::getAudioFileName(id).c_str();
            auto full = CCFileUtils::sharedFileUtils()->fullPathForFilename(off.c_str(), false);
            if (!full.empty() && std::filesystem::exists(std::string(full), ec)) path = full;
            else path.clear();
        }
        if (path.empty()) {
            say("Musique introuvable : télécharge-la d'abord.");
            return;
        }
        auto sc = GameLayer::scene(id, path, m_diff, 0);
        if (sc) CCDirector::sharedDirector()->pushScene(CCTransitionFade::create(0.3f, sc));
    }

    // ----- boucle -----
    void update(float dt) override {
        float W = m_ws.width, H = m_ws.height;
        float target = 0.f;
        if (!m_panel) {
            if (m_padL) target -= 240.f;
            if (m_padR) target += 240.f;
        }
        m_vx += (target - m_vx) * std::min(1.f, dt * 10.f);
        m_px = std::clamp(m_px + m_vx * dt, 0.f, m_WW - H * 0.12f);
        m_me->setPosition({m_px, m_floorH});
        m_padLbP->setVisible(m_padL);
        m_padRbP->setVisible(m_padR);

        // l'ordinateur marche doucement
        m_bx += m_bdir * 60.f * dt;
        if (m_bx > m_WW * 0.75f) m_bdir = -1.f;
        if (m_bx < m_WW * 0.5f) m_bdir = 1.f;
        m_bot->setPosition({m_bx, m_floorH});

        // caméra qui suit le joueur
        float goal = std::clamp(m_px - W * 0.4f, 0.f, m_WW - W);
        m_camX += (goal - m_camX) * std::min(1.f, dt * 6.f);
        m_world->setPosition({-m_camX, 0.f});

        // portes : éclairage et bouton ENTRER
        m_hotDoor = -1;
        for (int i = 0; i < 3; ++i) {
            float dx = std::fabs((m_px + H * 0.06f) - m_doorX[i]);
            bool near = dx < W * 0.12f;
            if (near) m_hotDoor = i;
            m_doorLabels[i]->setColor(near ? ccColor3B{255, 210, 90} : ccColor3B{255, 255, 255});
        }
        m_enterMenu->setVisible(m_hotDoor >= 0 && !m_panel);

        if (m_toastT > 0.f) {
            m_toastT -= dt;
            if (m_toastT <= 0.f) m_toast->setOpacity(0);
        }
    }
};

}  // namespace mg
